# Stock AI Platform

Production-style, modular research platform for stock direction prediction, ranking, and backtesting.

## Important Disclaimer
This repository is for educational and research purposes only. It does not provide financial advice. Model outputs are probabilistic and can be wrong.

## What This Platform Does
- Ingests historical OHLCV stock data from Yahoo Finance.
- Fetches financial news and sentiment from Alpha Vantage News & Sentiment API.
- Builds technical, sentiment, and market-context features with leakage-safe alignment.
- Trains multiple ML models with time-aware validation only.
- Generates next-day predictions and confidence rankings.
- Backtests a top-N selection strategy against a benchmark.
- Exposes APIs via FastAPI.
- Offers a lightweight Streamlit dashboard.
- Supports scheduled refresh/training/prediction jobs.

## Architecture
- `app/`: FastAPI application layer, API routes, service orchestration, app config/logging.
- `src/`: Core ML and data logic (ingestion, features, training, inference, backtesting).
- `dashboard/`: Streamlit UI.
- `data/`: Raw/processed data, model artifacts, outputs.
- `tests/`: Unit + API tests.
- `scripts/`: CLI entrypoint scripts.

## Project Layout
```
stock-ai-platform/
  app/
  src/
  dashboard/
  data/
  tests/
  scripts/
  README.md
  requirements.txt
  .env.example
  Dockerfile
  docker-compose.yml
```

## Setup
### 1) Python environment
```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Environment variables
```bash
cp .env.example .env
# populate ALPHA_VANTAGE_API_KEY if using live news
```

### 3) Run API
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 4) Run dashboard
```bash
streamlit run dashboard/streamlit_app.py
```

## Data Sources
- Historical: `yfinance` (default)
- News/Sentiment: Alpha Vantage News & Sentiment API
- Upgrade path: Polygon/Massive (placeholder config included)

## CLI Usage
```bash
python scripts/ingest_historical.py --symbols AAPL MSFT NVDA
python scripts/ingest_news.py --symbols AAPL MSFT NVDA
python scripts/build_dataset.py --symbols AAPL MSFT NVDA
python -m src.training.train --symbols AAPL MSFT NVDA
python -m src.inference.predict --symbols AAPL NVDA --model-name hist_gb_classifier
python -m src.backtesting.engine --symbols AAPL MSFT NVDA --start 2020-01-01 --end 2025-12-31
```

### Train From CSV (including Indian stocks)
If your CSV has symbols like `RELIANCE`, `TCS`, `INFY`, you can train directly from file.

```bash
PYTHONPATH=. python scripts/ingest_historical.py \
  --symbols-csv ./your_stocks.csv \
  --symbol-column symbol \
  --market india \
  --interval 1d

PYTHONPATH=. python scripts/train_models.py \
  --symbols-csv ./your_stocks.csv \
  --symbol-column symbol \
  --market india \
  --horizon-days 1
```

Checkpoint behavior:
- Progress is auto-saved to `data/outputs/checkpoints/train_from_csv_batches.json`.
- Re-running the same command automatically resumes from remaining symbols.
- Use `--reset-checkpoint` to restart from scratch.
- Symbols that repeatedly return zero historical rows are auto-marked unsupported in `data/outputs/checkpoints/unsupported_symbols.json` and skipped in future runs.
- Use `--reset-unsupported` to clear this list, or `--include-unsupported` to force retry them.

Notes:
- `--market india` automatically maps `RELIANCE` to `RELIANCE.NS` if no exchange suffix is provided.
- If your CSV column name is not `symbol`, pass `--symbol-column <column_name>`.

### Use sec_list.csv (NSE universe)
`sec_list.csv` can contain thousands of symbols. For stability and API limits, start with liquid boards and run batches.

```bash
PYTHONPATH=. python scripts/ingest_historical.py \
  --symbols-csv ./sec_list.csv \
  --symbol-column Symbol \
  --series-filter EQ \
  --market india \
  --max-symbols 200 \
  --interval 1d

PYTHONPATH=. python scripts/train_models.py \
  --symbols-csv ./sec_list.csv \
  --symbol-column Symbol \
  --series-filter EQ \
  --market india \
  --max-symbols 200 \
  --horizon-days 1
```

## API Endpoints
- `GET /health`
- `POST /ingest/historical`
- `POST /ingest/news`
- `POST /train`
- `POST /predict`
- `GET /watchlist`
- `GET /models`
- `GET /backtest`
- `GET /stocks/{symbol}/features`
- `GET /stocks/{symbol}/latest-prediction`

OpenAPI docs are available at `/docs`.

## Modeling Approach
### Leakage Prevention
- Strict time ordering.
- Targets created from future returns; features from current/past only.
- Walk-forward / time-series split validation.
- No random train/test split.

### Model Set
- Logistic Regression baseline
- RandomForest baseline
- HistGradientBoosting classifier
- Optional XGBoost classifier (if installed)

### Metrics
- Classification: accuracy, precision, recall, f1, roc-auc
- Regression: MAE, RMSE, directional accuracy
- Backtesting: cumulative return, drawdown, hit ratio, benchmark comparison

## Backtesting Notes
- Daily rebalancing into top-N predicted symbols.
- Equal-weight portfolio.
- Transaction cost assumption in basis points.
- Benchmark comparison against SPY by default.

## Scheduler Jobs
- Historical refresh (daily)
- News refresh (interval-based)
- Optional daily retraining
- Daily prediction generation

## Testing
```bash
pytest -q
```

Current tests cover feature engineering, target generation, training sanity, API health, and backtest sanity checks.

## News Impact Scanner (Phase 2)

### What was added
- Company-to-beneficiary relationship graph loaded from JSON.
- Company-to-ticker mapping with alias support loaded from JSON.
- Early opportunity scoring using weighted impact, relation strength, freshness, and price reaction.
- Price-reaction filter using `yfinance` to de-prioritize names that already moved too much.
- SQLAlchemy persistence for analyzed news items and signal history.
- Streamlit panel for Top Early Opportunities and a persisted Signal History table.

### JSON samples

Relationship graph example (`data/company_relations.json`):

```json
{
  "NTPC": {
    "ticker": "NTPC.NS",
    "aliases": ["National Thermal Power Corporation"],
    "sector": "Power",
    "relations": [
      {
        "company": "Power Grid",
        "ticker": "POWERGRID.NS",
        "relation": "transmission",
        "strength": 0.7
      },
      {
        "company": "BHEL",
        "ticker": "BHEL.NS",
        "relation": "equipment_supplier",
        "strength": 0.6
      }
    ]
  }
}
```

Ticker map example (`data/company_tickers.json`):

```json
{
  "NTPC": {
    "ticker": "NTPC.NS",
    "aliases": ["NTPC Ltd", "NTPC Limited"]
  },
  "Power Grid": {
    "ticker": "POWERGRID.NS",
    "aliases": ["Power Grid Corp", "Powergrid"]
  }
}
```

### SQLAlchemy model and migration notes
- Existing SQLAlchemy setup in `src/data/metadata_store.py` now defines two additional tables:
  - `analyzed_news_signals`: one row per analyzed article (`article_hash` unique).
  - `beneficiary_opportunities`: opportunity rows linked by `signal_id` foreign key.
- Additional non-breaking compatibility tables are also kept:
  - `news_impact_items`
  - `news_impact_signals`
- This project currently uses metadata-driven schema creation (`MetaData.create_all`) rather than Alembic migrations.
- Migration behavior:
  - New tables are created automatically on startup when missing.
  - Existing table alterations are not auto-migrated; for destructive schema changes use Alembic or a manual migration.

### Run and test

Run API:

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Run dashboard:

```bash
streamlit run dashboard/streamlit_app.py
```

Run News Impact Scanner focused tests:

```bash
pytest -q tests/test_ticker_map.py tests/test_relations.py tests/test_news_relations.py tests/test_news_scorer.py tests/test_news_metadata_store.py tests/test_news_analyzer.py tests/test_news_fetcher.py
```

## Signal Backtesting and Outcome Tracking

### What was added
- Signal-time snapshot persistence for beneficiary opportunities:
  - `signal_price`
  - `signal_timestamp`
  - `price_source`
- Outcome tracking table for horizon evaluations (1d, 3d, 5d, 7d by default).
- Backtest evaluation service with idempotent upsert behavior and safe fallbacks.
- Aggregate metrics and filtered history for event/sector/relation/timing/score-bucket analysis.
- Streamlit page: Signal Backtesting.
- Optional API endpoints:
  - `GET /news/backtest/summary`
  - `GET /news/backtest/signals`
  - `POST /news/backtest/run`

### Data quality and deterministic rules
- Entry price: `beneficiary_opportunities.signal_price` (captured at signal generation from yfinance close snapshot).
- Exit price: daily close from yfinance on target date, fallback to next available trading close (`next_available_close`).
- Non-trading day handling: target date is moved forward to the next available market close.
- Missing/invalid data behavior:
  - Horizon not elapsed: `pending`
  - Missing ticker/price data: `failed`
  - Valid entry + exit data: `completed`

### SQLAlchemy schema additions
- Extended `beneficiary_opportunities` with:
  - `signal_price`
  - `signal_timestamp`
  - `price_source`
- Added `signal_outcomes` table:
  - `opportunity_id` + `evaluation_horizon_days` unique pair enforced via unique constraint.
  - Upsert behavior updates existing rows instead of inserting duplicates.

### Migration notes
- This project uses `MetaData.create_all` for schema creation.
- New tables are auto-created when absent.
- Column additions on existing tables (`beneficiary_opportunities`) are not auto-migrated in existing DBs.
  - For an existing SQLite DB, run a manual migration or recreate DB in non-production contexts.

### Scheduler integration
- If enabled, pending signal outcomes are evaluated periodically by APScheduler.
- Config:
  - `BACKTEST_ENABLED`
  - `BACKTEST_SCHEDULER_ENABLED`
  - `BACKTEST_SCHEDULER_INTERVAL_MINUTES`

### Manual backfill / run

Run all pending evaluations via API:

```bash
curl -X POST http://localhost:8000/news/backtest/run
```

Inspect summary:

```bash
curl "http://localhost:8000/news/backtest/summary"
```

Inspect evaluated signal rows:

```bash
curl "http://localhost:8000/news/backtest/signals?max_rows=500"
```

Run focused tests for this phase:

```bash
pytest -q tests/test_news_backtest.py tests/test_news_metadata_store.py
```

## Watchlists, Alerts, and Notifications

### What was added
- User-defined watchlists for tracking companies, tickers, sectors, and event types.
- Alert rules with flexible filtering and matching logic.
- Generated alert persistence with cooldown-based deduplication.
- Pluggable notifier interface supporting:
  - In-app notifications (always available)
  - Webhook notifications
  - Email notifications (SMTP)
  - Telegram notifications
  - Slack notifications
- Streamlit page: Watchlists & Alerts.
- Optional API endpoints:
  - `POST /alerts/watchlists` – Create watchlist
  - `GET /alerts/watchlists` – List watchlists
  - `POST /alerts/watchlists/{id}/items` – Add item to watchlist
  - `POST /alerts/rules` – Create alert rule
  - `GET /alerts/rules` – List alert rules
  - `GET /alerts` – Get generated alerts
  - `POST /alerts/scan` – Manually trigger alert scan

### Features
- **Watchlist Management**: Create custom watchlists with company, ticker, sector, or event type filters.
- **Alert Rules**: Define rules with score thresholds, sentiment filters, timing labels, and notification channels.
- **Matching Engine**: Automatically evaluate new signals/opportunities against all active rules.
- **Cooldown Logic**: Prevent alert fatigue with configurable cooldown windows (default: 60 minutes).
- **Severity Classification**: Automatically calculate alert severity (high/warning/info) based on scores and timing.
- **Notification Channels**: Send alerts to multiple destinations simultaneously; gracefully degrade if external services unavailable.
- **Alert Feed**: View, filter, and acknowledge alerts in Streamlit.

### SQLAlchemy schema additions
- Added `watchlists` table: name, description, is_active.
- Added `watchlist_items` table: item_type, item_value, normalized_value with unique constraint per watchlist.
- Added `alert_rules` table: watchlist_id (nullable), sentiment/score/timing filters, notification channels, cooldown.
- Added `generated_alerts` table: rule_id, signal_id, opportunity_id, severity, status, dedupe_key.

### Integration points
- **News Service**: After beneficiary opportunities are persisted, alert matcher evaluates them against active rules.
- **Scheduler**: Optional periodic scan of recent opportunities (via `ALERT_SCAN_ENABLED` config).
- **Streamlit**: Dedicated page with tabs for watchlist management, rule creation, and alert feed.
- **API**: FastAPI routes for programmatic access to watchlists, rules, and alerts.

### Config settings
- `ALERTS_ENABLED` (default: true) – Master kill switch for alert system.
- `ALERT_SCAN_ENABLED` (default: false) – Enable scheduled background scans.
- `ALERT_SCAN_INTERVAL_MINUTES` (default: 60) – How often to scan recent opportunities.
- `DEFAULT_COOLDOWN_MINUTES` (default: 60) – Default dedup cooldown window.
- `ENABLED_NOTIFICATION_CHANNELS_RAW` (default: "in_app") – Comma-separated list of active channels.
- `MAX_ALERTS_IN_UI` (default: 500) – Max alerts shown in Streamlit.
- `MAX_RECENT_SIGNALS_FOR_ALERT_SCAN` (default: 100) – Lookback limit for scheduled scans.

### Notification channel config (optional)
- `WEBHOOK_URL` – HTTP endpoint for webhook notifications.
- `SMTP_ENABLED`, `SMTP_HOST`, `SMTP_PORT`, `SMTP_USERNAME`, `SMTP_PASSWORD` – Email config.
- `ALERT_EMAIL_FROM`, `ALERT_EMAIL_TO` – Email addresses.
- `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` – Telegram config.
- `SLACK_WEBHOOK_URL` – Slack incoming webhook.

### Example workflow
1. **Create a watchlist**: "Tech Earnings" with tickers AAPL, MSFT.
2. **Create a rule**: "Tech Positive Earnings" linked to "Tech Earnings", sentiment=positive, min_overall_score=0.75.
3. **New signal arrives**: AAPL earnings beat detected, score 0.82, sentiment positive.
4. **Alert matches rule**: Alert created with channels ["in_app", "slack"].
5. **Alert sent**: In-app alert stored in DB; Slack message posted; if Slack fails, alert marked failed but system continues.
6. **Cooldown**: Within 60 minutes, duplicate alerts for same rule + AAPL are suppressed.

### Data quality rules
- Normalization: Ticker/company/sector normalized to uppercase; event_type to lowercase with underscores.
- Duplicate prevention: Unique constraint on (watchlist_id, item_type, normalized_value).
- Alert dedup: Based on (rule_id, opportunity_id, channel) within cooldown window.
- Severity logic:
  - **High**: overall_score ≥ 0.8, confidence ≥ 0.75, timing = early
  - **Warning**: overall_score ≥ 0.65, confidence ≥ 0.60
  - **Info**: all others

### Graceful degradation
- If external notifier (webhook, email, Slack, Telegram) is misconfigured or unreachable, the alert is marked "failed" but in-app alert persists.
- In-app alerts always succeed; external channels are best-effort.
- Scheduler jobs respect `alerts_enabled` and `alert_scan_enabled` flags.

### Usage via Streamlit
1. Go to **Watchlists & Alerts** page.
2. **Watchlists tab**: Create watchlists and add items.
3. **Alert Rules tab**: Create rules with filters; select watchlist or leave empty for global.
4. **Alerts Feed tab**: View generated alerts; filter by status/severity/hours; mark alerts as seen; trigger manual scan.

### Manual scan and API
Trigger alert evaluation for recent opportunities:

```bash
curl -X POST http://localhost:8000/alerts/scan
```

List recent alerts:

```bash
curl "http://localhost:8000/alerts?hours=24&limit=50"
```

Run focused tests for this phase:

```bash
pytest -q tests/test_alerts.py
```

## Docker
```bash
docker compose up --build
```
API: `http://localhost:8000`
Dashboard: `http://localhost:8501`

## Known Limitations and Risks
- Free APIs have rate limits and potential data gaps.
- News relevance and sentiment fields may be sparse for some symbols.
- Market microstructure effects are simplified.
- Backtests are not execution-accurate and should not be interpreted as live-trading guarantees.

## Future Improvements
- SHAP explanations and model monitoring.
- Sector-aware and factor-neutral ranking.
- Portfolio optimizer and risk budgeting.
- Paper trading and alert integrations.
- Multi-horizon models (1d/3d/5d).
