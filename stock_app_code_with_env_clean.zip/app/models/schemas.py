from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class IngestHistoricalRequest(BaseModel):
    symbols: List[str]
    interval: str = "1d"
    lookback_days: int = 3650


class IngestNewsRequest(BaseModel):
    symbols: List[str]
    limit_per_symbol: int = 100


class TrainRequest(BaseModel):
    symbols: List[str]
    horizon_days: int = 1


class PredictRequest(BaseModel):
    symbols: List[str]
    horizon_days: int = 1
    model_name: str = "hist_gb_classifier"
    atr_multiplier: float = Field(default=1.0, ge=0.25, le=10.0)
    include_live_quote: bool = False


class PredictionItem(BaseModel):
    symbol: str
    price_as_of: Optional[str] = None
    price_as_of_time: Optional[str] = None
    current_price: Optional[float] = None
    live_price: Optional[float] = None
    live_price_as_of: Optional[str] = None
    live_price_as_of_time: Optional[str] = None
    live_price_source: Optional[str] = None
    target_price: Optional[float] = None
    stop_loss_price: Optional[float] = None
    prob_up: float
    predicted_return: float
    confidence: float
    latest_sentiment: float
    decision: str


class PredictResponse(BaseModel):
    generated_at: datetime
    predictions: List[PredictionItem]


class BacktestRequest(BaseModel):
    symbols: List[str]
    start: str
    end: str
    horizon_days: int = 1
    top_n: int = 5
    model_name: str = "hist_gb_classifier"


class BacktestResponse(BaseModel):
    metrics: dict
    rows: int


class TrainResponse(BaseModel):
    trained_at: datetime
    models: dict


class ErrorResponse(BaseModel):
    detail: str
