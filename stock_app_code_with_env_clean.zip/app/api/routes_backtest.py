from fastapi import APIRouter, HTTPException, Query

from app.services.backtest_service import backtest_service

router = APIRouter(tags=["backtest"])


@router.get("/backtest")
def backtest(
    symbols: str = Query(..., description="Comma separated symbols"),
    start: str = Query(...),
    end: str = Query(...),
    horizon_days: int = Query(1),
    top_n: int = Query(5),
    model_name: str = Query("hist_gb_classifier"),
) -> dict:
    parsed_symbols = [s.strip().upper() for s in symbols.split(",") if s.strip()]
    try:
        return backtest_service.backtest(parsed_symbols, start, end, horizon_days, top_n, model_name)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
