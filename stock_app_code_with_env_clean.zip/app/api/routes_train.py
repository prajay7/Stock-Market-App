from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException

from app.models.schemas import TrainRequest, TrainResponse
from app.services.training_service import training_service

router = APIRouter(tags=["training"])


@router.post("/train", response_model=TrainResponse)
def train(payload: TrainRequest) -> TrainResponse:
    try:
        models = training_service.train(payload.symbols, payload.horizon_days)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return TrainResponse(trained_at=datetime.now(timezone.utc), models=models)


@router.get("/models")
def list_models() -> dict:
    from app.core.config import get_settings
    from src.training.model_registry import ModelRegistry

    registry = ModelRegistry(get_settings().model_dir)
    return {"models": registry.list_models()}
