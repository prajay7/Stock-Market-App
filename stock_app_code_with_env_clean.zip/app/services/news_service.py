from __future__ import annotations

from app.core.config import get_settings
from src.data.news_loader import AlphaVantageNewsLoader


class NewsService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.loader = AlphaVantageNewsLoader(
            raw_data_dir=self.settings.raw_data_dir,
            api_key=self.settings.alpha_vantage_api_key,
            database_url=self.settings.database_url,
            timeout_sec=self.settings.request_timeout_sec,
        )

    def ingest_news(self, symbols: list[str], limit_per_symbol: int) -> dict[str, int]:
        return self.loader.ingest(symbols=symbols, limit_per_symbol=limit_per_symbol)


news_service = NewsService()
