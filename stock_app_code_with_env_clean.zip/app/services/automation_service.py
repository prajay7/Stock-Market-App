from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from app.core.config import get_settings
from app.news.service import news_impact_service
from app.services.data_service import data_service
from app.services.news_service import news_service
from app.services.prediction_service import prediction_service
from src.data.metadata_store import metadata_store

logger = logging.getLogger(__name__)


class AutomationService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.output_dir = self.settings.output_dir / "automation"
        self.output_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _utc_now() -> datetime:
        return datetime.now(timezone.utc)

    def _sec_list_symbols(self) -> list[str]:
        if not bool(self.settings.automation_use_sec_list):
            return []
        csv_path = Path("sec_list.csv")
        if not csv_path.exists():
            return []
        try:
            df = pd.read_csv(csv_path)
        except Exception:
            return []
        if "Symbol" not in df.columns:
            return []
        symbols = [str(sym).strip().upper() for sym in df["Symbol"].tolist() if str(sym).strip()]
        return symbols

    def _run_with_timeout(self, fn, *args, **kwargs):
        timeout_sec = max(1, int(self.settings.automation_step_timeout_sec))
        executor = ThreadPoolExecutor(max_workers=1)
        future = executor.submit(fn, *args, **kwargs)
        try:
            return future.result(timeout=timeout_sec)
        except FuturesTimeoutError:
            logger.warning("automation_step_timeout", extra={"function": getattr(fn, "__name__", str(fn)), "timeout_sec": timeout_sec})
            future.cancel()
            return None
        except Exception as exc:
            logger.warning("automation_step_failed", extra={"function": getattr(fn, "__name__", str(fn)), "error": str(exc)})
            return None
        finally:
            executor.shutdown(wait=False, cancel_futures=True)

    def _news_opportunity_symbols(self) -> list[str]:
        symbols: list[str] = []
        scan = self._run_with_timeout(
            news_impact_service.refresh,
            force_refresh=bool(self.settings.automation_force_news_refresh),
        )
        if scan is not None:
            for item in scan.top_opportunities:
                ticker = str(item.beneficiary_ticker or item.primary_ticker or "").strip().upper()
                if ticker:
                    symbols.append(ticker)

        try:
            recent = metadata_store.read_beneficiary_opportunities_with_signal(limit=500)
            for row in recent:
                ticker = str(row.get("ticker") or row.get("primary_ticker") or "").strip().upper()
                if ticker:
                    symbols.append(ticker)
        except Exception as exc:
            logger.warning("automation_opportunity_scan_failed", extra={"error": str(exc)})

        return symbols

    @staticmethod
    def _dedupe(symbols: list[str]) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for raw in symbols:
            symbol = str(raw).strip().upper()
            if not symbol or symbol in seen:
                continue
            seen.add(symbol)
            out.append(symbol)
        return out

    def build_universe(self) -> tuple[list[str], dict]:
        defaults = [str(sym).strip().upper() for sym in self.settings.default_symbols if str(sym).strip()]
        globals_ = [str(sym).strip().upper() for sym in self.settings.automation_global_symbols if str(sym).strip()]
        sec_list = self._sec_list_symbols()
        news = self._news_opportunity_symbols()

        sources = {
            "defaults": defaults,
            "global": globals_,
            "sec_list": sec_list,
            "news": news,
        }

        symbol_sources: dict[str, list[str]] = {}
        for source_name, symbols in sources.items():
            for raw in symbols:
                symbol = str(raw).strip().upper()
                if not symbol:
                    continue
                symbol_sources.setdefault(symbol, [])
                if source_name not in symbol_sources[symbol]:
                    symbol_sources[symbol].append(source_name)

        combined = []
        for values in sources.values():
            combined.extend(values)
        universe = self._dedupe(combined)
        final_universe = universe[: max(1, int(self.settings.automation_max_symbols))]

        breakdown = {
            "defaults_count": len(defaults),
            "global_count": len(globals_),
            "sec_list_count": len(sec_list),
            "news_count": len(news),
            "combined_unique_count": len(universe),
            "final_selected_count": len(final_universe),
            "symbol_sources": {symbol: symbol_sources.get(symbol, []) for symbol in final_universe},
        }
        return final_universe, breakdown

    def _resolve_prediction_model(self, model_override: str | None = None) -> str:
        override = str(model_override or "").strip()
        if override:
            return override
        configured = str(self.settings.automation_prediction_model or "auto").strip()
        if configured and configured.lower() != "auto":
            return configured
        if bool(self.settings.openai_predict_enabled):
            return "openai_stock_llm"
        return "hist_gb_classifier"

    @staticmethod
    def _opportunity_score_map(rows: list[dict]) -> dict[str, float]:
        best: dict[str, float] = {}
        for row in rows:
            ticker = str(row.get("ticker") or row.get("primary_ticker") or "").strip().upper()
            if not ticker:
                continue
            score = row.get("overall_score")
            try:
                score_value = float(score)
            except Exception:
                score_value = 0.0
            if ticker not in best or score_value > best[ticker]:
                best[ticker] = score_value
        return best

    def _rank_suggestions(self, predictions: list[dict]) -> list[dict]:
        recent = metadata_store.read_beneficiary_opportunities_with_signal(limit=1000)
        opp_map = self._opportunity_score_map(recent)

        ranked = []
        for row in predictions:
            symbol = str(row.get("symbol") or "").strip().upper()
            confidence = float(row.get("confidence") or 0.0)
            predicted_return = float(row.get("predicted_return") or 0.0)
            news_score = float(opp_map.get(symbol, 0.0))
            blended = (0.65 * confidence) + (0.25 * news_score) + (0.10 * max(predicted_return, 0.0))
            payload = {
                **row,
                "symbol": symbol,
                "news_opportunity_score": news_score,
                "blended_score": blended,
            }
            ranked.append(payload)

        ranked.sort(key=lambda item: float(item.get("blended_score") or 0.0), reverse=True)
        return ranked[: max(1, int(self.settings.automation_top_suggestions))]

    def _write_outputs(self, payload: dict) -> None:
        latest_path = self.output_dir / "auto_suggestions_latest.json"
        latest_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

        ts = self._utc_now().strftime("%Y%m%d%H%M%S")
        history_path = self.output_dir / f"auto_suggestions_{ts}.json"
        history_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

    def run_cycle(self, model_override: str | None = None, interval_minutes_override: int | None = None) -> dict:
        started_at = self._utc_now()
        symbols, source_breakdown = self.build_universe()
        interval_minutes = int(interval_minutes_override) if interval_minutes_override is not None else int(self.settings.automation_interval_minutes)
        historical_summary: dict[str, int] = {}
        historical_source_breakdown: dict[str, int] = {}
        if not symbols:
            result = {
                "started_at": started_at,
                "completed_at": self._utc_now(),
                "status": "no_symbols",
                "interval_minutes": interval_minutes,
                "symbol_count": 0,
                "predictions_count": 0,
                "source_breakdown": source_breakdown,
                "top_suggestions": [],
            }
            self._write_outputs(result)
            return result

        try:
            historical_result = self._run_with_timeout(
                data_service.ingest_historical,
                symbols,
                self.settings.historical_interval,
                self.settings.historical_lookback_days,
            )
            historical_summary = historical_result if isinstance(historical_result, dict) else {}
            historical_source_breakdown = dict(getattr(data_service.loader, "last_source_counts", {}) or {})
        except Exception as exc:
            logger.warning("automation_historical_ingest_failed", extra={"error": str(exc)})

        try:
            self._run_with_timeout(news_service.ingest_news, symbols, int(self.settings.max_news_items_per_symbol))
        except Exception as exc:
            logger.warning("automation_news_ingest_failed", extra={"error": str(exc)})

        prediction_model = self._resolve_prediction_model(model_override=model_override)
        prediction_result = prediction_service.predict(
            symbols=symbols,
            model_name=prediction_model,
            horizon_days=int(self.settings.automation_horizon_days),
            atr_multiplier=1.0,
            include_live_quote=bool(self.settings.automation_include_live_quote),
        )
        predictions = prediction_result.get("predictions", [])
        top_suggestions = self._rank_suggestions(predictions)

        result = {
            "started_at": started_at,
            "completed_at": self._utc_now(),
            "status": "ok",
            "interval_minutes": interval_minutes,
            "prediction_model": prediction_model,
            "symbol_count": len(symbols),
            "predictions_count": len(predictions),
            "source_breakdown": source_breakdown,
            "historical_ingest_summary": {
                "symbols_with_rows": sum(1 for _, rows in historical_summary.items() if int(rows) > 0),
                "symbols_without_rows": sum(1 for _, rows in historical_summary.items() if int(rows) <= 0),
            },
            "historical_source_breakdown": historical_source_breakdown,
            "symbols": symbols,
            "top_suggestions": top_suggestions,
        }
        self._write_outputs(result)
        return result

    def latest(self) -> dict:
        latest_path = self.output_dir / "auto_suggestions_latest.json"
        if not latest_path.exists():
            return {
                "status": "empty",
                "top_suggestions": [],
            }
        try:
            return json.loads(latest_path.read_text(encoding="utf-8"))
        except Exception:
            return {
                "status": "corrupt",
                "top_suggestions": [],
            }


automation_service = AutomationService()
