"""
Watchlist service for managing user-defined watchlists and items.
"""
from __future__ import annotations

import logging
from datetime import datetime

from app.core.config import get_settings
from app.news.models import Watchlist, WatchlistItem
from src.data.metadata_store import metadata_store

logger = logging.getLogger(__name__)


class WatchlistService:
    """Service for managing watchlists and their items."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self.store = metadata_store

    def create_watchlist(self, name: str, description: str = "", is_active: bool = True) -> Watchlist:
        """Create a new watchlist."""
        try:
            watchlist_id = self.store.create_watchlist(name, description, is_active)
            return self._read_watchlist_by_id(watchlist_id)
        except Exception as e:
            logger.error(f"Failed to create watchlist {name}: {e}")
            raise

    def read_watchlists(self, active_only: bool = False) -> list[Watchlist]:
        """Read all watchlists with their items."""
        try:
            rows = self.store.read_watchlists(active_only=active_only)
            watchlists = []
            for row in rows:
                watchlist = Watchlist(**row)
                watchlist.items = self.read_watchlist_items(row["id"])
                watchlists.append(watchlist)
            return watchlists
        except Exception as e:
            logger.error(f"Failed to read watchlists: {e}")
            return []

    def read_watchlist(self, watchlist_id: int) -> Watchlist | None:
        """Read a single watchlist with its items."""
        try:
            return self._read_watchlist_by_id(watchlist_id)
        except Exception as e:
            logger.error(f"Failed to read watchlist {watchlist_id}: {e}")
            return None

    def _read_watchlist_by_id(self, watchlist_id: int) -> Watchlist | None:
        """Internal method to read a single watchlist with items."""
        row = self.store.read_watchlist(watchlist_id)
        if not row:
            return None
        watchlist = Watchlist(**row)
        watchlist.items = self.read_watchlist_items(watchlist_id)
        return watchlist

    def update_watchlist(
        self, watchlist_id: int, name: str = None, description: str = None, is_active: bool = None
    ) -> Watchlist | None:
        """Update a watchlist."""
        try:
            self.store.update_watchlist(watchlist_id, name, description, is_active)
            return self._read_watchlist_by_id(watchlist_id)
        except Exception as e:
            logger.error(f"Failed to update watchlist {watchlist_id}: {e}")
            return None

    def delete_watchlist(self, watchlist_id: int) -> bool:
        """Delete a watchlist and all its items."""
        try:
            self.store.delete_watchlist(watchlist_id)
            logger.info(f"Deleted watchlist {watchlist_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete watchlist {watchlist_id}: {e}")
            return False

    def create_watchlist_item(
        self, watchlist_id: int, item_type: str, item_value: str
    ) -> WatchlistItem | None:
        """
        Create a watchlist item.
        Supported item types: company, ticker, sector, event_type
        """
        try:
            normalized = self._normalize_item_value(item_type, item_value)
            item_id = self.store.create_watchlist_item(watchlist_id, item_type, item_value, normalized)
            return WatchlistItem(
                id=item_id,
                watchlist_id=watchlist_id,
                item_type=item_type,
                item_value=item_value,
                normalized_value=normalized,
                created_at=datetime.utcnow(),
            )
        except Exception as e:
            logger.error(f"Failed to create watchlist item {item_type}={item_value}: {e}")
            return None

    def read_watchlist_items(self, watchlist_id: int) -> list[WatchlistItem]:
        """Read all items in a watchlist."""
        try:
            rows = self.store.read_watchlist_items(watchlist_id)
            return [WatchlistItem(**row) for row in rows]
        except Exception as e:
            logger.error(f"Failed to read items for watchlist {watchlist_id}: {e}")
            return []

    def delete_watchlist_item(self, item_id: int) -> bool:
        """Delete a watchlist item."""
        try:
            self.store.delete_watchlist_item(item_id)
            logger.info(f"Deleted watchlist item {item_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete watchlist item {item_id}: {e}")
            return False

    @staticmethod
    def _normalize_item_value(item_type: str, item_value: str) -> str:
        """Normalize item values for consistent matching."""
        if item_type in ("ticker", "company"):
            return str(item_value).upper().strip()
        if item_type == "sector":
            return str(item_value).upper().strip()
        if item_type == "event_type":
            return str(item_value).lower().strip().replace(" ", "_")
        return str(item_value).upper().strip()

    def get_items_by_type(self, watchlist_id: int, item_type: str) -> list[str]:
        """Get normalized values of a specific item type from a watchlist."""
        items = self.read_watchlist_items(watchlist_id)
        return [item.normalized_value for item in items if item.item_type == item_type]


watchlist_service = WatchlistService()
