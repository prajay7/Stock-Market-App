from __future__ import annotations

from app.core.config import get_settings
from src.data.historical_loader import HistoricalLoader


class DataService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.loader = HistoricalLoader(
            self.settings.raw_data_dir,
            alpha_vantage_api_key=self.settings.alpha_vantage_api_key,
            stooq_api_key=self.settings.stooq_api_key,
            data_provider=self.settings.data_provider,
        )

    def ingest_historical(self, symbols: list[str], interval: str, lookback_days: int) -> dict[str, int]:
        return self.loader.ingest(symbols=symbols, interval=interval, lookback_days=lookback_days)


data_service = DataService()
