from __future__ import annotations

import logging

from apscheduler.schedulers.background import BackgroundScheduler

from app.core.config import get_settings
from app.news.backtest_service import news_signal_backtest_service
from app.services.alert_matcher_service import alert_matcher_service
from app.services.automation_service import automation_service
from app.services.data_service import data_service
from app.services.news_service import news_service
from app.services.paper_trading_service import paper_trading_service
from app.services.prediction_service import prediction_service
from app.services.training_service import training_service

logger = logging.getLogger(__name__)


class SchedulerService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.scheduler = BackgroundScheduler(timezone="UTC")
        self._started = False

    def start(self) -> None:
        if self._started:
            return
        symbols = self.settings.default_symbols

        self.scheduler.add_job(
            lambda: data_service.ingest_historical(symbols, self.settings.historical_interval, self.settings.historical_lookback_days),
            trigger="cron",
            hour=22,
            minute=30,
            id="daily_historical_refresh",
            replace_existing=True,
        )
        self.scheduler.add_job(
            lambda: news_service.ingest_news(symbols, self.settings.max_news_items_per_symbol),
            trigger="interval",
            minutes=self.settings.news_refresh_minutes,
            id="news_refresh",
            replace_existing=True,
        )
        self.scheduler.add_job(
            lambda: training_service.train(symbols, 1),
            trigger="cron",
            hour=23,
            minute=0,
            id="daily_train",
            replace_existing=True,
        )
        self.scheduler.add_job(
            lambda: prediction_service.predict(symbols, "hist_gb_classifier", 1),
            trigger="cron",
            hour=23,
            minute=10,
            id="daily_predict",
            replace_existing=True,
        )

        if self.settings.backtest_enabled and self.settings.backtest_scheduler_enabled:
            self.scheduler.add_job(
                lambda: news_signal_backtest_service.evaluate_pending_outcomes(),
                trigger="interval",
                minutes=max(1, int(self.settings.backtest_scheduler_interval_minutes)),
                id="news_signal_backtest_evaluator",
                replace_existing=True,
                max_instances=1,
            )

        if self.settings.alerts_enabled and self.settings.alert_scan_enabled:
            self.scheduler.add_job(
                lambda: alert_matcher_service.scan_recent_opportunities(),
                trigger="interval",
                minutes=max(1, int(self.settings.alert_scan_interval_minutes)),
                id="alert_rule_scanner",
                replace_existing=True,
                max_instances=1,
            )

        if self.settings.paper_trading_enabled and self.settings.paper_trading_price_refresh_enabled:
            self.scheduler.add_job(
                lambda: paper_trading_service.refresh_open_trades(limit=self.settings.paper_trading_price_refresh_limit),
                trigger="interval",
                minutes=max(1, int(self.settings.paper_trading_price_refresh_interval_minutes)),
                id="paper_trade_price_refresh",
                replace_existing=True,
                max_instances=1,
            )

        if self.settings.automation_enabled:
            self.scheduler.add_job(
                lambda: automation_service.run_cycle(),
                trigger="interval",
                minutes=max(1, int(self.settings.automation_interval_minutes)),
                id="automation_cycle_runner",
                replace_existing=True,
                max_instances=1,
            )

        self.scheduler.start()
        self._started = True
        logger.info("scheduler_started")

    def shutdown(self) -> None:
        if self._started:
            self.scheduler.shutdown(wait=False)
            self._started = False


scheduler_service = SchedulerService()
