from __future__ import annotations

from src.training.train import train_models


class TrainingService:
    def train(self, symbols: list[str], horizon_days: int) -> dict:
        return train_models(symbols=symbols, horizon_days=horizon_days)


training_service = TrainingService()
