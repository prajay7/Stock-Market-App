from __future__ import annotations

from datetime import datetime, timezone

from app.core.config import get_settings
from src.data.metadata_store import MetadataStore
from src.inference.predict import predict_for_symbols


class PredictionService:
    def predict(
        self,
        symbols: list[str],
        model_name: str,
        horizon_days: int,
        atr_multiplier: float = 1.0,
        include_live_quote: bool = False,
    ):
        df = predict_for_symbols(
            symbols=symbols,
            model_name=model_name,
            horizon_days=horizon_days,
            atr_multiplier=atr_multiplier,
            include_live_quote=include_live_quote,
        )
        settings = get_settings()
        MetadataStore(settings.database_url).write_predictions(df.to_dict(orient="records"), model_name=model_name)
        return {
            "generated_at": datetime.now(timezone.utc),
            "predictions": df.to_dict(orient="records"),
        }


prediction_service = PredictionService()
