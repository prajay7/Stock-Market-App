from __future__ import annotations

from src.backtesting.engine import run_backtest


class BacktestService:
    def backtest(self, symbols: list[str], start: str, end: str, horizon_days: int, top_n: int, model_name: str) -> dict:
        result = run_backtest(symbols=symbols, start=start, end=end, horizon_days=horizon_days, top_n=top_n, model_name=model_name)
        return {"metrics": result.metrics, "rows": len(result.daily)}


backtest_service = BacktestService()
