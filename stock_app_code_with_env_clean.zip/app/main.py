from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api.routes_alerts import router as alerts_router
from app.api.routes_automation import router as automation_router
from app.api.routes_backtest import router as backtest_router
from app.api.routes_data import router as data_router
from app.api.routes_health import router as health_router
from app.api.routes_news_backtest import router as news_backtest_router
from app.api.routes_predict import router as predict_router
from app.api.routes_trades import router as trades_router
from app.api.routes_train import router as train_router
from app.core.config import get_settings
from app.core.logger import setup_logging
from app.services.scheduler_service import scheduler_service

settings = get_settings()
setup_logging(settings.log_level)


@asynccontextmanager
async def lifespan(_: FastAPI):
    if settings.scheduler_enabled:
        scheduler_service.start()
    try:
        yield
    finally:
        scheduler_service.shutdown()


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    lifespan=lifespan,
    description="Educational stock prediction and backtesting platform.",
)

app.include_router(health_router)
app.include_router(data_router)
app.include_router(train_router)
app.include_router(predict_router)
app.include_router(backtest_router)
app.include_router(news_backtest_router)
app.include_router(alerts_router)
app.include_router(trades_router)
app.include_router(automation_router)
