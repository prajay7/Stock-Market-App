from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path

import joblib
import pandas as pd

from app.core.config import get_settings
from src.backtesting.metrics import summary_metrics
from src.backtesting.plots import save_equity_plot
from src.training.dataset_builder import build_and_save_dataset


@dataclass
class BacktestResult:
    daily: pd.DataFrame
    trades: pd.DataFrame
    metrics: dict


def _latest_model_path(model_dir: Path, model_name: str) -> Path:
    candidates = sorted(model_dir.glob(f"{model_name}_*.joblib"))
    if not candidates:
        raise FileNotFoundError(f"No artifacts found for model {model_name}")
    return candidates[-1]


def run_backtest(symbols: list[str], start: str, end: str, horizon_days: int = 1, top_n: int = 5, model_name: str = "hist_gb_classifier") -> BacktestResult:
    settings = get_settings()
    model_path = _latest_model_path(settings.model_dir, model_name)
    metadata_path = model_path.with_suffix("").with_name(model_path.stem + ".metadata.json")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    feature_cols = metadata["feature_list"]
    model = joblib.load(model_path)

    dataset_path = build_and_save_dataset(settings.raw_data_dir, settings.processed_data_dir, symbols + [settings.benchmark_symbol], settings.historical_interval, horizon_days)
    df = pd.read_parquet(dataset_path).sort_values(["date", "symbol"]).reset_index(drop=True)

    df = df[(df["date"] >= pd.to_datetime(start)) & (df["date"] <= pd.to_datetime(end))].copy()
    if df.empty:
        raise ValueError("No rows in selected backtest period")

    model_preds = []
    for dt, group in df.groupby("date"):
        scored = group[["date", "symbol", "forward_return_1d"]].copy()
        X = group[feature_cols].replace([float("inf"), float("-inf")], pd.NA).fillna(0.0)
        if hasattr(model, "predict_proba"):
            scored["score"] = model.predict_proba(X)[:, 1]
        else:
            scored["score"] = model.predict(X)
        model_preds.append(scored)
    pred_df = pd.concat(model_preds, ignore_index=True)

    trade_rows = []
    daily_rows = []

    for dt, group in pred_df.groupby("date"):
        benchmark_ret = group.loc[group["symbol"] == settings.benchmark_symbol, "forward_return_1d"]
        benchmark_ret = float(benchmark_ret.iloc[0]) if not benchmark_ret.empty else 0.0

        tradable = group[group["symbol"] != settings.benchmark_symbol].sort_values("score", ascending=False).head(top_n)
        if tradable.empty:
            port_ret = 0.0
        else:
            gross = float(tradable["forward_return_1d"].fillna(0.0).mean())
            tx_cost = settings.transaction_cost_bps / 10000.0
            port_ret = gross - tx_cost

            for _, row in tradable.iterrows():
                trade_rows.append(
                    {
                        "date": dt,
                        "symbol": row["symbol"],
                        "score": row["score"],
                        "forward_return_1d": row["forward_return_1d"],
                    }
                )

        daily_rows.append({"date": dt, "portfolio_return": port_ret, "benchmark_return": benchmark_ret})

    daily = pd.DataFrame(daily_rows).sort_values("date").reset_index(drop=True)
    daily["portfolio_equity"] = (1 + daily["portfolio_return"]).cumprod()
    daily["benchmark_equity"] = (1 + daily["benchmark_return"].fillna(0.0)).cumprod()

    metrics = summary_metrics(daily["portfolio_return"], daily["benchmark_return"])
    trades = pd.DataFrame(trade_rows)

    metrics_path = settings.output_dir / "backtest_metrics.json"
    trades_path = settings.output_dir / "backtest_trades.parquet"
    daily_path = settings.output_dir / "backtest_daily.parquet"

    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    trades.to_parquet(trades_path, index=False)
    daily.to_parquet(daily_path, index=False)
    save_equity_plot(daily, settings.output_dir / "backtest_equity_curve.png")

    return BacktestResult(daily=daily, trades=trades, metrics=metrics)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbols", nargs="+", required=False)
    parser.add_argument("--start", required=True)
    parser.add_argument("--end", required=True)
    parser.add_argument("--horizon-days", type=int, default=1)
    parser.add_argument("--top-n", type=int, default=5)
    parser.add_argument("--model-name", type=str, default="hist_gb_classifier")
    args = parser.parse_args()

    settings = get_settings()
    symbols = args.symbols or settings.default_symbols
    res = run_backtest(symbols, args.start, args.end, args.horizon_days, args.top_n, args.model_name)
    print(json.dumps(res.metrics, indent=2))


if __name__ == "__main__":
    main()
