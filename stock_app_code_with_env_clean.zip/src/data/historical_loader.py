from __future__ import annotations

import logging
import time
from io import StringIO
from dataclasses import dataclass, field
from datetime import date, timedelta
import json
from pathlib import Path

import httpx
import pandas as pd
import yfinance as yf
from tenacity import retry, stop_after_attempt, wait_exponential

from src.data.cache import symbol_price_path
from src.data.storage import append_dedup_by_keys, read_parquet_if_exists, write_parquet
from src.utils.symbols import normalize_symbols
from src.utils.validation import validate_ohlcv_frame

logger = logging.getLogger(__name__)


@dataclass
class HistoricalLoader:
    raw_data_dir: Path
    alpha_vantage_api_key: str = ""
    stooq_api_key: str = ""
    data_provider: str = "alphavantage"
    last_diagnostics: dict[str, str] = field(default_factory=dict, init=False)
    last_source_by_symbol: dict[str, str] = field(default_factory=dict, init=False)
    last_source_counts: dict[str, int] = field(default_factory=dict, init=False)

    def _stooq_url(self, ticker: str, masked: bool = False) -> str:
        base = f"https://stooq.com/q/d/l/?s={ticker}&i=d"
        if not self.stooq_api_key:
            return base
        if masked:
            return f"{base}&apikey=***"
        return f"{base}&apikey={self.stooq_api_key}"

    def _snapshot_dir(self) -> Path:
        return self.raw_data_dir.parent / "outputs" / "debug" / "ingest_failures"

    def _save_failure_snapshot(
        self,
        symbol: str,
        interval: str,
        lookback_days: int,
        diagnostics: list[str],
        debug_records: list[dict[str, str]],
    ) -> Path:
        out_dir = self._snapshot_dir()
        out_dir.mkdir(parents=True, exist_ok=True)
        ts = pd.Timestamp.utcnow().strftime("%Y%m%d%H%M%S")
        safe_symbol = str(symbol).replace("/", "_").replace(" ", "_")
        out_path = out_dir / f"{safe_symbol}_{ts}.json"
        payload = {
            "symbol": symbol,
            "interval": interval,
            "lookback_days": int(lookback_days),
            "saved_at": pd.Timestamp.utcnow().isoformat(),
            "diagnostics": diagnostics,
            "attempts": debug_records,
        }
        out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return out_path

    @staticmethod
    def _stooq_requires_apikey(debug_records: list[dict[str, str]]) -> bool:
        for record in debug_records:
            if str(record.get("source", "")).lower() != "stooq":
                continue
            preview = str(record.get("preview", "")).lower()
            if "get_apikey" in preview or "append the <apikey>" in preview:
                return True
        return False

    @retry(wait=wait_exponential(min=1, max=16), stop=stop_after_attempt(3), reraise=True)
    def _download(self, symbol: str, start: date, interval: str) -> pd.DataFrame:
        ticker = yf.Ticker(symbol)
        df = ticker.history(start=start.isoformat(), interval=interval, auto_adjust=False)
        if df is None or df.empty:
            return pd.DataFrame()

        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [col[0] if isinstance(col, tuple) else col for col in df.columns]

        df = df.reset_index().rename(
            columns={
                "Date": "date",
                "Datetime": "date",
                "Open": "open",
                "High": "high",
                "Low": "low",
                "Close": "close",
                "Volume": "volume",
            }
        )
        keep = [c for c in ["date", "open", "high", "low", "close", "volume"] if c in df.columns]
        df = df[keep]
        df["date"] = pd.to_datetime(df["date"]).dt.tz_localize(None)
        df["symbol"] = symbol
        return df.sort_values("date").reset_index(drop=True)

    def _stooq_symbol_candidates(self, symbol: str) -> list[str]:
        cleaned = str(symbol).strip().upper()
        base = cleaned.split(".")[0].lower()
        suffix = cleaned.split(".")[-1] if "." in cleaned else ""

        out: list[str] = []
        seen: set[str] = set()

        def _add(v: str) -> None:
            if v and v not in seen:
                out.append(v)
                seen.add(v)

        _add(cleaned.lower())
        _add(base)

        # Indian symbols are commonly represented as .in on Stooq.
        if suffix in {"NS", "NSE", "BO", "BSE"} or cleaned.endswith(".NS") or cleaned.endswith(".BO"):
            _add(f"{base}.in")

        # Keep .us as broad fallback for US/default symbols.
        _add(f"{base}.us")
        return out

    def _download_stooq_daily(self, symbol: str, start: date) -> pd.DataFrame:
        # Fallback for provider throttling. Try multiple Stooq ticker namespaces.
        with httpx.Client(timeout=20.0) as client:
            for ticker in self._stooq_symbol_candidates(symbol):
                url = self._stooq_url(ticker, masked=False)
                try:
                    resp = client.get(url)
                    resp.raise_for_status()
                except Exception:
                    continue

                csv_text = resp.text.strip()
                if not csv_text or "Date,Open,High,Low,Close,Volume" not in csv_text:
                    continue

                raw = pd.read_csv(StringIO(csv_text))
                raw = raw.rename(
                    columns={
                        "Date": "date",
                        "Open": "open",
                        "High": "high",
                        "Low": "low",
                        "Close": "close",
                        "Volume": "volume",
                    }
                )
                raw["date"] = pd.to_datetime(raw["date"], errors="coerce")
                raw = raw[raw["date"].notna()]
                raw = raw[raw["date"] >= pd.Timestamp(start)]
                if raw.empty:
                    continue
                raw["symbol"] = symbol
                return raw[["date", "open", "high", "low", "close", "volume", "symbol"]].sort_values("date").reset_index(drop=True)

        return pd.DataFrame()

    def _download_stooq_daily_with_debug(self, symbol: str, start: date) -> tuple[pd.DataFrame, list[dict[str, str]]]:
        debug: list[dict[str, str]] = []
        with httpx.Client(timeout=20.0) as client:
            for ticker in self._stooq_symbol_candidates(symbol):
                url = self._stooq_url(ticker, masked=False)
                safe_url = self._stooq_url(ticker, masked=True)
                try:
                    resp = client.get(url)
                    status = str(resp.status_code)
                    preview = (resp.text or "")[:1200]
                    debug.append({"source": "stooq", "ticker": ticker, "url": safe_url, "status": status, "preview": preview})
                    resp.raise_for_status()
                except Exception as exc:
                    debug.append({"source": "stooq", "ticker": ticker, "url": safe_url, "status": "error", "preview": str(exc)[:300]})
                    continue

                csv_text = resp.text.strip()
                if not csv_text or "Date,Open,High,Low,Close,Volume" not in csv_text:
                    continue

                raw = pd.read_csv(StringIO(csv_text))
                raw = raw.rename(
                    columns={
                        "Date": "date",
                        "Open": "open",
                        "High": "high",
                        "Low": "low",
                        "Close": "close",
                        "Volume": "volume",
                    }
                )
                raw["date"] = pd.to_datetime(raw["date"], errors="coerce")
                raw = raw[raw["date"].notna()]
                raw = raw[raw["date"] >= pd.Timestamp(start)]
                if raw.empty:
                    continue
                raw["symbol"] = symbol
                return raw[["date", "open", "high", "low", "close", "volume", "symbol"]].sort_values("date").reset_index(drop=True), debug

        return pd.DataFrame(), debug

    def _download_nse_daily_with_debug(self, symbol: str, start: date) -> tuple[pd.DataFrame, list[dict[str, str]]]:
        debug: list[dict[str, str]] = []
        base_symbol = str(symbol).upper().split(".")[0]
        symbol_candidates = [base_symbol, str(symbol).upper()]
        from_str = pd.Timestamp(start).strftime("%d-%m-%Y")
        to_str = pd.Timestamp(date.today()).strftime("%d-%m-%Y")
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/json,text/plain,*/*",
            "Referer": "https://www.nseindia.com/",
        }

        with httpx.Client(timeout=20.0, follow_redirects=True, headers=headers) as client:
            try:
                client.get("https://www.nseindia.com/")
            except Exception as exc:
                debug.append({"source": "nse", "ticker": base_symbol, "url": "https://www.nseindia.com/", "status": "error", "preview": str(exc)[:300]})

            for candidate in symbol_candidates:
                for series in ["EQ", "BE", "SM"]:
                    url = "https://www.nseindia.com/api/historical/cm/equity"
                    params = {
                        "symbol": candidate,
                        "series": f'["{series}"]',
                        "from": from_str,
                        "to": to_str,
                    }
                    try:
                        resp = client.get(url, params=params)
                        status = str(resp.status_code)
                        text_preview = (resp.text or "")[:1200]
                        debug.append(
                            {
                                "source": "nse",
                                "ticker": candidate,
                                "series": series,
                                "url": str(resp.url),
                                "status": status,
                                "preview": text_preview,
                            }
                        )
                        resp.raise_for_status()
                        payload = resp.json()
                    except Exception as exc:
                        debug.append(
                            {
                                "source": "nse",
                                "ticker": candidate,
                                "series": series,
                                "url": url,
                                "status": "error",
                                "preview": str(exc)[:300],
                            }
                        )
                        continue

                    data = payload.get("data") or []
                    if not data:
                        continue

                    rows = []
                    for item in data:
                        dt = pd.to_datetime(item.get("CH_TIMESTAMP"), errors="coerce")
                        if pd.isna(dt) or dt < pd.Timestamp(start):
                            continue
                        rows.append(
                            {
                                "date": dt,
                                "open": pd.to_numeric(item.get("CH_OPENING_PRICE"), errors="coerce"),
                                "high": pd.to_numeric(item.get("CH_TRADE_HIGH_PRICE"), errors="coerce"),
                                "low": pd.to_numeric(item.get("CH_TRADE_LOW_PRICE"), errors="coerce"),
                                "close": pd.to_numeric(item.get("CH_CLOSING_PRICE"), errors="coerce"),
                                "volume": pd.to_numeric(item.get("CH_TOT_TRADED_QTY"), errors="coerce"),
                                "symbol": symbol,
                            }
                        )

                    if not rows:
                        continue

                    out = pd.DataFrame(rows).dropna(subset=["date", "open", "high", "low", "close", "volume"])
                    if out.empty:
                        continue
                    out["date"] = pd.to_datetime(out["date"]).dt.tz_localize(None)
                    out = out.sort_values("date").drop_duplicates(subset=["date"], keep="last").reset_index(drop=True)
                    return out, debug

        return pd.DataFrame(), debug

    def _download_alpha_vantage_daily(self, symbol: str, start: date) -> pd.DataFrame:
        if not self.alpha_vantage_api_key:
            return pd.DataFrame()

        url = "https://www.alphavantage.co/query"
        params = {
            "function": "TIME_SERIES_DAILY",
            "symbol": symbol,
            "outputsize": "compact",
            "apikey": self.alpha_vantage_api_key,
        }
        time.sleep(1.1)
        with httpx.Client(timeout=20.0) as client:
            resp = client.get(url, params=params)
            resp.raise_for_status()
            payload = resp.json()

        series = payload.get("Time Series (Daily)")
        if not series:
            return pd.DataFrame()

        records = []
        for ds, values in series.items():
            dt = pd.to_datetime(ds, errors="coerce")
            if pd.isna(dt) or dt < pd.Timestamp(start):
                continue
            records.append(
                {
                    "date": dt,
                    "open": pd.to_numeric(values.get("1. open"), errors="coerce"),
                    "high": pd.to_numeric(values.get("2. high"), errors="coerce"),
                    "low": pd.to_numeric(values.get("3. low"), errors="coerce"),
                    "close": pd.to_numeric(values.get("4. close"), errors="coerce"),
                    "volume": pd.to_numeric(values.get("5. volume"), errors="coerce"),
                    "symbol": symbol,
                }
            )

        if not records:
            return pd.DataFrame()

        out = pd.DataFrame(records).dropna(subset=["date", "open", "high", "low", "close", "volume"])
        return out.sort_values("date").reset_index(drop=True)

    def _alpha_symbol_candidates(self, symbol: str) -> list[str]:
        base = symbol.upper().split(".")[0]
        candidates = [symbol.upper(), base, f"{base}.BSE", f"{base}.BO", f"{base}.NS", f"{base}.NSE"]
        seen = set()
        out = []
        for c in candidates:
            if c not in seen:
                out.append(c)
                seen.add(c)
        return out

    def _internet_symbol_candidates(self, symbol: str) -> list[str]:
        base = symbol.upper().split(".")[0]
        candidates = [symbol.upper(), base, f"{base}.NS", f"{base}.BO", f"{base}.NSE", f"{base}.BSE"]
        seen = set()
        out = []
        for c in candidates:
            if c not in seen:
                out.append(c)
                seen.add(c)
        return out

    def _download_best_effort_with_variants(self, symbol: str, start: date, interval: str) -> pd.DataFrame:
        # Last resort internet scrape across common exchange symbol variants.
        for candidate in self._internet_symbol_candidates(symbol):
            try:
                df = self._download(candidate, start=start, interval=interval)
                if not df.empty:
                    df["symbol"] = symbol
                    return df
            except Exception:
                pass

            if interval == "1d":
                try:
                    df = self._download_stooq_daily(candidate, start=start)
                    if not df.empty:
                        df["symbol"] = symbol
                        return df
                except Exception:
                    pass

        return pd.DataFrame()

    def _download_alpha_vantage_best_effort(self, symbol: str, start: date) -> pd.DataFrame:
        for candidate in self._alpha_symbol_candidates(symbol):
            try:
                df = self._download_alpha_vantage_daily(candidate, start)
                if not df.empty:
                    # Keep original symbol namespace in downstream storage.
                    df["symbol"] = symbol
                    return df
            except Exception:
                continue
        return pd.DataFrame()

    def ingest(
        self,
        symbols: list[str],
        interval: str = "1d",
        lookback_days: int = 3650,
        direct_internet_scrape: bool = False,
        save_failure_snapshot: bool = False,
    ) -> dict[str, int]:
        symbols = normalize_symbols(symbols)
        summary: dict[str, int] = {}
        self.last_diagnostics = {}
        self.last_source_by_symbol = {}
        self.last_source_counts = {}
        provider = str(self.data_provider or "alphavantage").strip().lower()
        force_direct_scrape = direct_internet_scrape or provider in {"google", "internet", "scrape"}

        for symbol in symbols:
            diagnostics: list[str] = []
            debug_records: list[dict[str, str]] = []
            path = symbol_price_path(self.raw_data_dir, symbol, interval)
            existing = read_parquet_if_exists(path)
            if not existing.empty:
                existing.columns = [str(c).strip().lower() for c in existing.columns]
                if "datetime" in existing.columns and "date" not in existing.columns:
                    existing = existing.rename(columns={"datetime": "date"})
                if not {"date", "symbol"}.issubset(set(existing.columns)):
                    existing = pd.DataFrame()

            if existing.empty:
                start = date.today() - timedelta(days=lookback_days)
            else:
                existing["date"] = pd.to_datetime(existing["date"]).dt.tz_localize(None)
                last_date = existing["date"].max().date()
                start = last_date - timedelta(days=7)

            fresh = pd.DataFrame()
            source_used = ""

            if force_direct_scrape:
                # Explicit direct mode: NSE -> Yahoo -> Stooq.
                if interval == "1d":
                    try:
                        fresh, nse_debug = self._download_nse_daily_with_debug(symbol, start=start)
                        debug_records.extend(nse_debug)
                        if not fresh.empty:
                            source_used = "nse"
                            logger.info("historical_direct_nse_used", extra={"symbol": symbol, "rows": len(fresh)})
                        else:
                            diagnostics.append("nse:no_rows")
                    except Exception as exc:
                        diagnostics.append(f"nse:error:{type(exc).__name__}")
                        logger.warning("historical_direct_nse_failed", extra={"symbol": symbol, "error": str(exc)})

                if fresh.empty:
                    try:
                        fresh = self._download(symbol, start=start, interval=interval)
                        if fresh.empty:
                            diagnostics.append("yahoo:no_rows")
                            debug_records.append(
                                {
                                    "source": "yahoo",
                                    "ticker": symbol,
                                    "status": "no_rows",
                                    "preview": "yfinance returned empty dataframe",
                                }
                            )
                        else:
                            source_used = "yahoo"
                            logger.info("historical_direct_yahoo_used", extra={"symbol": symbol, "rows": len(fresh)})
                    except Exception as exc:
                        diagnostics.append(f"yahoo:error:{type(exc).__name__}")
                        debug_records.append(
                            {
                                "source": "yahoo",
                                "ticker": symbol,
                                "status": "error",
                                "preview": str(exc)[:300],
                            }
                        )
                        logger.warning("historical_direct_yahoo_failed", extra={"symbol": symbol, "error": str(exc)})
                        fresh = pd.DataFrame()

                if fresh.empty and interval == "1d":
                    try:
                        fresh, stooq_debug = self._download_stooq_daily_with_debug(symbol, start=start)
                        debug_records.extend(stooq_debug)
                        if not fresh.empty:
                            source_used = "stooq"
                            logger.info("historical_direct_stooq_used", extra={"symbol": symbol, "rows": len(fresh)})
                        else:
                            if self._stooq_requires_apikey(stooq_debug):
                                diagnostics.append("stooq:apikey_required")
                            else:
                                diagnostics.append("stooq:no_rows")
                    except Exception as exc:
                        diagnostics.append(f"stooq:error:{type(exc).__name__}")
                        logger.warning("historical_direct_stooq_failed", extra={"symbol": symbol, "error": str(exc)})
            else:
                # Default mode: Alpha Vantage first, then internet fallbacks.
                use_alpha_primary = interval == "1d" and bool(self.alpha_vantage_api_key) and provider != "yahoo"

                if use_alpha_primary:
                    try:
                        fresh = self._download_alpha_vantage_best_effort(symbol, start=start)
                        if not fresh.empty:
                            source_used = "alpha_vantage"
                            logger.info("historical_primary_alpha_vantage_used", extra={"symbol": symbol, "rows": len(fresh)})
                        else:
                            diagnostics.append("alpha_vantage:no_rows")
                    except Exception as exc:
                        diagnostics.append(f"alpha_vantage:error:{type(exc).__name__}")
                        logger.warning("historical_primary_alpha_vantage_failed", extra={"symbol": symbol, "error": str(exc)})

                if fresh.empty:
                    try:
                        fresh = self._download(symbol, start=start, interval=interval)
                        if fresh.empty:
                            diagnostics.append("yahoo:no_rows")
                        else:
                            source_used = "yahoo"
                    except Exception as exc:
                        diagnostics.append(f"yahoo:error:{type(exc).__name__}")
                        logger.info(
                            "historical_yahoo_primary_failed_fallbacking",
                            extra={"symbol": symbol, "error": str(exc)},
                        )
                        fresh = pd.DataFrame()

                if fresh.empty and interval == "1d":
                    try:
                        fresh, stooq_debug = self._download_stooq_daily_with_debug(symbol, start=start)
                        debug_records.extend(stooq_debug)
                        if not fresh.empty:
                            source_used = "stooq"
                            logger.info("historical_fallback_stooq_used", extra={"symbol": symbol, "rows": len(fresh)})
                        else:
                            if self._stooq_requires_apikey(stooq_debug):
                                diagnostics.append("stooq:apikey_required")
                            else:
                                diagnostics.append("stooq:no_rows")
                    except Exception as exc:
                        diagnostics.append(f"stooq:error:{type(exc).__name__}")
                        logger.warning("historical_fallback_failed", extra={"symbol": symbol, "error": str(exc)})

                if fresh.empty:
                    try:
                        fresh = self._download_best_effort_with_variants(symbol, start=start, interval=interval)
                        if not fresh.empty:
                            source_used = "variant"
                            logger.info(
                                "historical_variant_scrape_used",
                                extra={"symbol": symbol, "rows": len(fresh)},
                            )
                        else:
                            diagnostics.append("variant_scrape:no_rows")
                    except Exception as exc:
                        diagnostics.append(f"variant_scrape:error:{type(exc).__name__}")
                        logger.warning("historical_variant_scrape_failed", extra={"symbol": symbol, "error": str(exc)})

            if fresh.empty:
                if not existing.empty:
                    # Preserve cached rows when provider calls are temporarily rate-limited.
                    existing = existing.sort_values(["symbol", "date"]).reset_index(drop=True)
                    validate_ohlcv_frame(existing)
                    write_parquet(existing, path)
                    summary[symbol] = len(existing)
                    logger.info("historical_cached_used", extra={"symbol": symbol, "rows": len(existing)})
                    self.last_diagnostics[symbol] = "cached_rows_used"
                    self.last_source_by_symbol[symbol] = "cache"
                    continue

                logger.warning(
                    "historical_all_providers_failed",
                    extra={
                        "symbol": symbol,
                        "diagnostics": diagnostics,
                    },
                )
                logger.info("no_historical_data", extra={"symbol": symbol})
                summary[symbol] = 0
                if save_failure_snapshot:
                    snap = self._save_failure_snapshot(symbol, interval, lookback_days, diagnostics, debug_records)
                    diagnostics.append(f"snapshot:{snap}")
                self.last_diagnostics[symbol] = "; ".join(diagnostics) if diagnostics else "no_provider_rows"
                self.last_source_by_symbol[symbol] = "none"
                continue

            fresh.columns = [str(c).strip().lower() for c in fresh.columns]
            if "datetime" in fresh.columns and "date" not in fresh.columns:
                fresh = fresh.rename(columns={"datetime": "date"})
            if not {"date", "symbol"}.issubset(set(fresh.columns)):
                logger.warning("historical_payload_missing_keys", extra={"symbol": symbol, "columns": list(fresh.columns)})
                summary[symbol] = 0
                self.last_diagnostics[symbol] = "payload_missing_keys"
                self.last_source_by_symbol[symbol] = source_used or "invalid_payload"
                continue

            combined = append_dedup_by_keys(existing, fresh, keys=["symbol", "date"])
            combined = combined.sort_values(["symbol", "date"]).reset_index(drop=True)
            validate_ohlcv_frame(combined)
            write_parquet(combined, path)
            summary[symbol] = len(combined)
            self.last_diagnostics[symbol] = f"ok_rows:{len(combined)}"
            self.last_source_by_symbol[symbol] = source_used or "unknown"
            logger.info("historical_ingested", extra={"symbol": symbol, "rows": len(combined)})

        counts: dict[str, int] = {}
        for source in self.last_source_by_symbol.values():
            key = str(source or "unknown").strip().lower() or "unknown"
            counts[key] = int(counts.get(key, 0)) + 1
        self.last_source_counts = counts

        return summary
