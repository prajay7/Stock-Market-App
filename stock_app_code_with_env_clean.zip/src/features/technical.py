from __future__ import annotations

import numpy as np
import pandas as pd


def compute_rsi(close: pd.Series, window: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)
    avg_gain = gain.rolling(window=window, min_periods=window).mean()
    avg_loss = loss.rolling(window=window, min_periods=window).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def compute_macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> pd.DataFrame:
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd = ema_fast - ema_slow
    signal_line = macd.ewm(span=signal, adjust=False).mean()
    hist = macd - signal_line
    return pd.DataFrame({"macd": macd, "macd_signal": signal_line, "macd_hist": hist})


def compute_atr(df: pd.DataFrame, window: int = 14) -> pd.Series:
    high_low = df["high"] - df["low"]
    high_prev_close = (df["high"] - df["close"].shift(1)).abs()
    low_prev_close = (df["low"] - df["close"].shift(1)).abs()
    tr = pd.concat([high_low, high_prev_close, low_prev_close], axis=1).max(axis=1)
    return tr.rolling(window=window, min_periods=window).mean()


def build_technical_features(price_df: pd.DataFrame) -> pd.DataFrame:
    df = price_df.copy().sort_values(["symbol", "date"]).reset_index(drop=True)

    df["return_1d"] = df.groupby("symbol")["close"].pct_change()
    df["log_return_1d"] = np.log1p(df["return_1d"])

    for lag in [1, 2, 3, 5, 10]:
        df[f"return_lag_{lag}"] = df.groupby("symbol")["return_1d"].shift(lag)

    for win in [5, 10, 20, 50, 200]:
        df[f"sma_{win}"] = df.groupby("symbol")["close"].transform(lambda s: s.rolling(win, min_periods=win).mean())
        df[f"close_to_sma_{win}"] = df["close"] / df[f"sma_{win}"]

    for win in [5, 10, 20, 50]:
        df[f"vol_mean_{win}"] = df.groupby("symbol")["volume"].transform(lambda s: s.rolling(win, min_periods=win).mean())
        df[f"return_std_{win}"] = df.groupby("symbol")["return_1d"].transform(lambda s: s.rolling(win, min_periods=win).std())

    df["volume_change_1d"] = df.groupby("symbol")["volume"].pct_change()

    df["rsi_14"] = df.groupby("symbol")["close"].transform(lambda s: compute_rsi(s, 14))
    macd_df = df.groupby("symbol", group_keys=False)["close"].apply(lambda s: compute_macd(s))
    df[["macd", "macd_signal", "macd_hist"]] = macd_df[["macd", "macd_signal", "macd_hist"]].values

    atr_parts = []
    for _, group in df.groupby("symbol", sort=False):
        atr_series = compute_atr(group, 14)
        atr_series.index = group.index
        atr_parts.append(atr_series)
    if atr_parts:
        df["atr_14"] = pd.concat(atr_parts).sort_index()
    else:
        df["atr_14"] = np.nan

    df["day_of_week"] = df["date"].dt.dayofweek
    df["month"] = df["date"].dt.month
    df["is_month_start"] = df["date"].dt.is_month_start.astype(int)
    df["is_month_end"] = df["date"].dt.is_month_end.astype(int)

    benchmark = (
        df[df["symbol"] == "SPY"][["date", "return_1d"]]
        .rename(columns={"return_1d": "benchmark_return_1d"})
        .drop_duplicates(subset=["date"])
    )
    df = df.merge(benchmark, on="date", how="left")
    df["relative_return_1d"] = df["return_1d"] - df["benchmark_return_1d"]

    return df
