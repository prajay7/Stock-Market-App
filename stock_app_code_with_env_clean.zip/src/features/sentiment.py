from __future__ import annotations

import pandas as pd


def merge_sentiment_features(features_df: pd.DataFrame, sentiment_daily_df: pd.DataFrame) -> pd.DataFrame:
    if sentiment_daily_df.empty:
        out = features_df.copy()
        out["sentiment_same_day"] = 0.0
        out["sentiment_3d"] = 0.0
        out["sentiment_7d"] = 0.0
        out["news_count"] = 0
        return out

    left = features_df.copy()
    right = sentiment_daily_df.copy()
    left["date"] = pd.to_datetime(left["date"]).dt.floor("D")
    right["date"] = pd.to_datetime(right["date"]).dt.floor("D")

    merged = left.merge(
        right[["symbol", "date", "sentiment_same_day", "sentiment_3d", "sentiment_7d", "news_count"]],
        on=["symbol", "date"],
        how="left",
    )
    for c in ["sentiment_same_day", "sentiment_3d", "sentiment_7d"]:
        merged[c] = merged[c].fillna(0.0)
    merged["news_count"] = merged["news_count"].fillna(0).astype(int)
    return merged
