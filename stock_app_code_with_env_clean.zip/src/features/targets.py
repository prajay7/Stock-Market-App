from __future__ import annotations

import pandas as pd


def add_classification_target(df: pd.DataFrame, horizon_days: int = 1) -> pd.DataFrame:
    out = df.copy().sort_values(["symbol", "date"]).reset_index(drop=True)
    future_return = out.groupby("symbol")["close"].shift(-horizon_days) / out["close"] - 1.0
    out[f"target_up_{horizon_days}d"] = (future_return > 0).astype(int)
    out[f"forward_return_{horizon_days}d"] = future_return
    return out


def add_regression_target(df: pd.DataFrame, horizon_days: int = 1) -> pd.DataFrame:
    out = df.copy().sort_values(["symbol", "date"]).reset_index(drop=True)
    out[f"target_return_{horizon_days}d"] = out.groupby("symbol")["close"].shift(-horizon_days) / out["close"] - 1.0
    return out


def add_outperform_target(df: pd.DataFrame, benchmark_symbol: str, horizon_days: int = 3) -> pd.DataFrame:
    out = df.copy().sort_values(["symbol", "date"]).reset_index(drop=True)
    out[f"forward_return_{horizon_days}d"] = out.groupby("symbol")["close"].shift(-horizon_days) / out["close"] - 1.0

    benchmark = out[out["symbol"] == benchmark_symbol][["date", f"forward_return_{horizon_days}d"]].rename(
        columns={f"forward_return_{horizon_days}d": "benchmark_forward_return"}
    )
    out = out.merge(benchmark, on="date", how="left")
    out[f"target_outperform_{horizon_days}d"] = (out[f"forward_return_{horizon_days}d"] > out["benchmark_forward_return"]).astype(int)
    return out
