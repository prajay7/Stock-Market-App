from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import httpx
import joblib
import numpy as np
import pandas as pd

from app.core.config import get_settings
from src.data.cache import symbol_price_path
from src.data.historical_loader import HistoricalLoader
from src.inference.rank import rank_predictions
from src.training.dataset_builder import build_and_save_dataset


def _latest_model_path(model_dir: Path, model_name: str) -> Path:
    candidates = sorted(model_dir.glob(f"{model_name}_*.joblib"))
    if not candidates:
        raise FileNotFoundError(f"No artifacts found for model {model_name}")
    return candidates[-1]


def _metadata_path_from_model(model_path: Path) -> Path:
    return model_path.with_suffix("").with_name(model_path.stem + ".metadata.json")


def _alpha_symbol_candidates(symbol: str) -> list[str]:
    base = str(symbol).upper().split(".")[0]
    candidates = [symbol.upper(), base, f"{base}.BSE", f"{base}.BO", f"{base}.NS", f"{base}.NSE"]
    seen = set()
    out = []
    for candidate in candidates:
        if candidate not in seen:
            out.append(candidate)
            seen.add(candidate)
    return out


def _fetch_live_quote_alpha_vantage(
    symbol: str,
    api_key: str,
    timeout_sec: float = 20.0,
) -> tuple[float | None, str | None, str | None, str | None]:
    if not api_key:
        return None, None, None, None

    url = "https://www.alphavantage.co/query"
    with httpx.Client(timeout=timeout_sec) as client:
        for candidate in _alpha_symbol_candidates(symbol):
            try:
                time.sleep(1.1)
                intraday_params = {
                    "function": "TIME_SERIES_INTRADAY",
                    "symbol": candidate,
                    "interval": "1min",
                    "outputsize": "compact",
                    "apikey": api_key,
                }
                intraday_payload = client.get(url, params=intraday_params).json()
                series_key = next((k for k in intraday_payload.keys() if k.startswith("Time Series")), None)
                if series_key and isinstance(intraday_payload.get(series_key), dict):
                    series = intraday_payload[series_key]
                    if series:
                        latest_key = max(series.keys())
                        latest_bar = series.get(latest_key, {})
                        px = pd.to_numeric(latest_bar.get("4. close"), errors="coerce")
                        ts = pd.to_datetime(latest_key, errors="coerce")
                        if pd.notna(px):
                            ts_date = ts.strftime("%Y-%m-%d") if pd.notna(ts) else None
                            ts_time = ts.strftime("%H:%M:%S") if pd.notna(ts) else None
                            return float(px), ts_date, ts_time, "alphavantage_intraday_1min"
            except Exception:
                pass

            try:
                time.sleep(1.1)
                quote_params = {
                    "function": "GLOBAL_QUOTE",
                    "symbol": candidate,
                    "apikey": api_key,
                }
                quote_payload = client.get(url, params=quote_params).json()
                quote = quote_payload.get("Global Quote", {})
                px = pd.to_numeric(quote.get("05. price"), errors="coerce")
                latest_day = quote.get("07. latest trading day")
                if pd.notna(px):
                    return float(px), str(latest_day) if latest_day else None, "00:00:00", "alphavantage_global_quote"
            except Exception:
                pass

    return None, None, None, None


def _safe_float(value, default: float | None = None) -> float | None:
    try:
        num = float(value)
    except Exception:
        return default
    if np.isnan(num) or np.isinf(num):
        return default
    return num


def _extract_json_object(raw_text: str) -> dict:
    text = str(raw_text or "").strip()
    if not text:
        return {}
    try:
        payload = json.loads(text)
        return payload if isinstance(payload, dict) else {}
    except Exception:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return {}
    try:
        payload = json.loads(text[start : end + 1])
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _llm_feature_snapshot(row: pd.Series) -> dict:
    keys = [
        "close",
        "open",
        "high",
        "low",
        "volume",
        "ret_1d",
        "ret_5d",
        "ret_20d",
        "rsi_14",
        "atr_14",
        "sma_20",
        "sma_50",
        "macd",
        "macd_signal",
        "sentiment_same_day",
    ]
    out: dict[str, float | None] = {}
    for key in keys:
        out[key] = _safe_float(row.get(key), None)
    return out


def _predict_symbol_with_openai(row: pd.Series, settings, horizon_days: int) -> dict:
    symbol = str(row.get("symbol") or "").upper().strip()
    sentiment = _safe_float(row.get("sentiment_same_day"), 0.0) or 0.0
    current_price = _safe_float(row.get("close"), 0.0) or 0.0

    api_key = settings.openai_predict_api_key_effective
    if not api_key:
        return {
            "symbol": symbol,
            "prob_up": 0.50,
            "predicted_return": 0.0,
            "confidence": 0.50,
            "latest_sentiment": sentiment,
            "decision": "HOLD",
            "llm_reason": "missing_api_key",
        }

    feature_snapshot = _llm_feature_snapshot(row)
    system_prompt = (
        "You are a conservative quant assistant for short-horizon stock movement forecasting. "
        "Return only one compact JSON object with keys: prob_up, predicted_return, confidence, decision, reason. "
        "Rules: prob_up in [0,1], predicted_return in [-0.2,0.2], confidence in [0,1], "
        "decision must be BUY_CANDIDATE or HOLD."
    )
    user_prompt = {
        "symbol": symbol,
        "horizon_days": int(horizon_days),
        "features": feature_snapshot,
        "current_price": current_price,
        "latest_sentiment": sentiment,
    }

    url = str(settings.openai_predict_base_url).rstrip("/") + "/chat/completions"
    request_payload = {
        "model": str(settings.openai_predict_model_name),
        "temperature": float(settings.openai_predict_temperature),
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": json.dumps(user_prompt, ensure_ascii=True)},
        ],
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        with httpx.Client(timeout=float(settings.openai_predict_timeout_sec or settings.request_timeout_sec)) as client:
            resp = client.post(url, headers=headers, json=request_payload)
            resp.raise_for_status()
            payload = resp.json()
        content = str(payload.get("choices", [{}])[0].get("message", {}).get("content", ""))
        pred = _extract_json_object(content)
    except Exception:
        pred = {}

    prob_up = _safe_float(pred.get("prob_up"), 0.50)
    predicted_return = _safe_float(pred.get("predicted_return"), 0.0)
    confidence = _safe_float(pred.get("confidence"), prob_up)
    decision = str(pred.get("decision") or "HOLD").strip().upper()
    if decision not in {"BUY_CANDIDATE", "HOLD"}:
        decision = "BUY_CANDIDATE" if (prob_up or 0.50) >= 0.55 else "HOLD"

    prob_up = float(np.clip(prob_up if prob_up is not None else 0.50, 0.0, 1.0))
    predicted_return = float(np.clip(predicted_return if predicted_return is not None else 0.0, -0.20, 0.20))
    confidence = float(np.clip(confidence if confidence is not None else prob_up, 0.0, 1.0))

    return {
        "symbol": symbol,
        "prob_up": prob_up,
        "predicted_return": predicted_return,
        "confidence": confidence,
        "latest_sentiment": sentiment,
        "decision": decision,
        "llm_reason": str(pred.get("reason") or ""),
    }


def _ensure_price_cache_for_symbols(settings, symbols: list[str], interval: str, horizon_days: int) -> None:
    normalized = [str(sym).strip().upper() for sym in symbols if str(sym).strip()]
    missing = [
        sym
        for sym in normalized
        if not symbol_price_path(settings.raw_data_dir, sym, interval).exists()
    ]
    if not missing:
        return

    loader = HistoricalLoader(
        settings.raw_data_dir,
        alpha_vantage_api_key=settings.alpha_vantage_api_key,
        stooq_api_key=settings.stooq_api_key,
    )
    loader.ingest(
        symbols=missing,
        interval=interval,
        lookback_days=max(int(settings.historical_lookback_days), int(horizon_days) + 40),
        direct_internet_scrape=False,
        save_failure_snapshot=False,
    )


def predict_for_symbols(
    symbols: list[str],
    model_name: str = "hist_gb_classifier",
    horizon_days: int = 1,
    atr_multiplier: float = 1.0,
    include_live_quote: bool = False,
) -> pd.DataFrame:
    settings = get_settings()
    _ensure_price_cache_for_symbols(settings, symbols, settings.historical_interval, int(horizon_days))
    dataset_path = build_and_save_dataset(settings.raw_data_dir, settings.processed_data_dir, symbols, settings.historical_interval, horizon_days)
    df = pd.read_parquet(dataset_path).sort_values(["date", "symbol"]).reset_index(drop=True)

    latest = df.groupby("symbol", as_index=False).tail(1).copy()

    if str(model_name).strip().lower() == "openai_stock_llm":
        if not settings.openai_predict_enabled:
            raise ValueError("OpenAI predictor is disabled. Set OPENAI_PREDICT_ENABLED=true.")
        llm_rows = [_predict_symbol_with_openai(row, settings, int(horizon_days)) for _, row in latest.iterrows()]
        llm_df = pd.DataFrame(llm_rows)
        latest = latest.merge(llm_df, on="symbol", how="left")
    else:
        model_path = _latest_model_path(settings.model_dir, model_name)
        metadata_path = _metadata_path_from_model(model_path)
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        feature_cols = metadata["feature_list"]

        X = latest[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0.0)
        model = joblib.load(model_path)

        prob_up = model.predict_proba(X)[:, 1] if hasattr(model, "predict_proba") else model.predict(X)
        latest["prob_up"] = prob_up
        latest["predicted_return"] = latest["prob_up"] - 0.5
        latest["confidence"] = latest["prob_up"]
        latest["latest_sentiment"] = latest.get("sentiment_same_day", 0.0)
        latest["decision"] = np.where(latest["prob_up"] >= 0.55, "BUY_CANDIDATE", "HOLD")

    latest["current_price"] = pd.to_numeric(latest.get("close"), errors="coerce")
    price_ts = pd.to_datetime(latest.get("date"), errors="coerce")
    latest["price_as_of"] = price_ts.dt.strftime("%Y-%m-%d")
    latest["price_as_of_time"] = price_ts.dt.strftime("%H:%M:%S")
    latest["live_price"] = np.nan
    latest["live_price_as_of"] = None
    latest["live_price_as_of_time"] = None
    latest["live_price_source"] = None

    if include_live_quote:
        quote_map = {
            sym: _fetch_live_quote_alpha_vantage(
                sym,
                settings.alpha_vantage_api_key,
                settings.request_timeout_sec,
            )
            for sym in latest["symbol"].astype(str).tolist()
        }
        latest["live_price"] = latest["symbol"].map(lambda s: quote_map.get(str(s), (None, None, None, None))[0])
        latest["live_price_as_of"] = latest["symbol"].map(lambda s: quote_map.get(str(s), (None, None, None, None))[1])
        latest["live_price_as_of_time"] = latest["symbol"].map(lambda s: quote_map.get(str(s), (None, None, None, None))[2])
        latest["live_price_source"] = latest["symbol"].map(lambda s: quote_map.get(str(s), (None, None, None, None))[3])

    expected_move = pd.to_numeric(latest["predicted_return"], errors="coerce").fillna(0.0).clip(lower=-0.20, upper=0.20)
    latest["target_price"] = (latest["current_price"] * (1.0 + expected_move)).clip(lower=0.0)

    atr = pd.to_numeric(latest.get("atr_14"), errors="coerce") if "atr_14" in latest.columns else pd.Series(np.nan, index=latest.index)
    risk_mult = max(0.25, float(atr_multiplier))
    fallback_stop_distance = (latest["current_price"] * np.maximum(expected_move.abs() * 0.5, 0.01) * risk_mult).clip(lower=0.01)
    stop_distance = np.where(np.isfinite(atr) & (atr > 0), atr * risk_mult, fallback_stop_distance)
    direction = np.where(expected_move >= 0, 1.0, -1.0)
    latest["stop_loss_price"] = (latest["current_price"] - direction * stop_distance).clip(lower=0.0)

    out = latest[
        [
            "symbol",
            "price_as_of",
            "price_as_of_time",
            "current_price",
            "live_price",
            "live_price_as_of",
            "live_price_as_of_time",
            "live_price_source",
            "target_price",
            "stop_loss_price",
            "prob_up",
            "predicted_return",
            "confidence",
            "latest_sentiment",
            "decision",
        ]
    ].sort_values(
        "confidence", ascending=False
    )

    predictions_path = settings.output_dir / "latest_predictions.parquet"
    out.to_parquet(predictions_path, index=False)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbols", nargs="+", required=False)
    parser.add_argument("--horizon-days", type=int, default=1)
    parser.add_argument("--model-name", type=str, default="hist_gb_classifier")
    parser.add_argument("--atr-multiplier", type=float, default=1.0)
    parser.add_argument("--include-live-quote", action="store_true")
    parser.add_argument("--top-n", type=int, default=5)
    args = parser.parse_args()

    settings = get_settings()
    symbols = args.symbols or settings.default_symbols
    pred = predict_for_symbols(
        symbols=symbols,
        model_name=args.model_name,
        horizon_days=args.horizon_days,
        atr_multiplier=args.atr_multiplier,
        include_live_quote=args.include_live_quote,
    )
    ranked = rank_predictions(pred, top_n=args.top_n)
    print(ranked.to_json(orient="records", indent=2))


if __name__ == "__main__":
    main()
