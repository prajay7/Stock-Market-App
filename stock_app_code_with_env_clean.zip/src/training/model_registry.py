from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib


@dataclass
class ModelRegistry:
    model_dir: Path

    def save_model(self, model: Any, model_name: str, version: str) -> Path:
        path = self.model_dir / f"{model_name}_{version}.joblib"
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(model, path)
        return path

    def save_metadata(self, model_name: str, version: str, metadata: dict[str, Any]) -> Path:
        payload = {
            "model_name": model_name,
            "version": version,
            "saved_at": datetime.now(timezone.utc).isoformat(),
            **metadata,
        }
        path = self.model_dir / f"{model_name}_{version}.metadata.json"
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path

    def list_models(self) -> list[str]:
        return sorted([p.name for p in self.model_dir.glob("*.joblib")])
