from __future__ import annotations

import argparse
import json
from datetime import date, datetime, timezone

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import TimeSeriesSplit

from app.core.config import get_settings
from src.data.cache import symbol_price_path
from src.data.historical_loader import HistoricalLoader
from src.data.storage import read_parquet_if_exists
from src.training.dataset_builder import build_and_save_dataset
from src.training.evaluate import classification_metrics
from src.training.model_registry import ModelRegistry
from src.utils.symbols import normalize_symbols


def _build_models() -> dict[str, object]:
    models = {
        "log_reg_classifier": LogisticRegression(max_iter=500, class_weight="balanced"),
        "rf_classifier": RandomForestClassifier(n_estimators=300, max_depth=8, random_state=42, n_jobs=-1),
        "hist_gb_classifier": HistGradientBoostingClassifier(max_depth=6, learning_rate=0.05, random_state=42),
    }
    try:
        from xgboost import XGBClassifier

        models["xgboost_classifier"] = XGBClassifier(
            n_estimators=300,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            eval_metric="logloss",
            random_state=42,
        )
    except Exception:
        pass
    return models


def _recommended_n_splits(row_count: int) -> int:
    # Favor faster training for small/medium runs while keeping enough temporal validation.
    if row_count < 300:
        return 2
    if row_count < 1500:
        return 3
    if row_count < 5000:
        return 4
    return 5


def _is_symbol_updated_today(raw_data_dir, symbol: str, interval: str) -> bool:
    path = symbol_price_path(raw_data_dir, symbol, interval)
    existing = read_parquet_if_exists(path)
    if existing.empty:
        return False

    cols = {str(c).strip().lower(): c for c in existing.columns}
    date_col = cols.get("date") or cols.get("datetime")
    if date_col is None:
        return False

    last_ts = pd.to_datetime(existing[date_col], errors="coerce").dropna()
    if last_ts.empty:
        return False
    return bool(last_ts.max().date() >= date.today())


def _select_features(df: pd.DataFrame) -> list[str]:
    exclude = {
        "date",
        "symbol",
        "target_up_1d",
        "target_return_1d",
        "forward_return_1d",
    }
    return [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]


def train_models(symbols: list[str], horizon_days: int = 1, refresh_prices: bool = True) -> dict:
    settings = get_settings()
    symbols = normalize_symbols(symbols)
    ingest_summary: dict[str, int] = {}
    if refresh_prices:
        stale_symbols = [
            symbol
            for symbol in symbols
            if not _is_symbol_updated_today(settings.raw_data_dir, symbol, settings.historical_interval)
        ]
        if stale_symbols:
            loader = HistoricalLoader(
                settings.raw_data_dir,
                alpha_vantage_api_key=settings.alpha_vantage_api_key,
                stooq_api_key=settings.stooq_api_key,
            )
            ingest_summary = loader.ingest(
                stale_symbols,
                interval=settings.historical_interval,
                lookback_days=settings.historical_lookback_days,
            )
        stale_set = set(stale_symbols)
        fresh_symbols = [symbol for symbol in symbols if symbol not in stale_set]
        for symbol in fresh_symbols:
            ingest_summary[symbol] = 0

    dataset_path = build_and_save_dataset(settings.raw_data_dir, settings.processed_data_dir, symbols, settings.historical_interval, horizon_days)
    df = pd.read_parquet(dataset_path).sort_values(["date", "symbol"]).reset_index(drop=True)

    target_col = f"target_up_{horizon_days}d"
    df = df.dropna(subset=[target_col]).copy()

    feature_cols = _select_features(df)
    X = df[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0.0)
    y = df[target_col].astype(int)

    if len(X) <= 2:
        raise ValueError("Not enough rows for time-series validation (need at least 3 rows)")
    n_splits = min(_recommended_n_splits(len(X)), len(X) - 1)
    if len(X) <= n_splits:
        raise ValueError(f"Not enough rows ({len(X)}) for time-series validation with {n_splits} splits")
    tscv = TimeSeriesSplit(n_splits=n_splits)
    registry = ModelRegistry(settings.model_dir)

    results: dict[str, dict] = {}
    version = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")

    for name, model in _build_models().items():
        fold_metrics = []
        for train_idx, val_idx in tscv.split(X):
            X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

            model.fit(X_train, y_train)
            y_pred = model.predict(X_val)
            y_prob = model.predict_proba(X_val)[:, 1] if hasattr(model, "predict_proba") else None
            fold_metrics.append(classification_metrics(y_val, y_pred, y_prob))

        mean_metrics = {k: float(np.mean([fm[k] for fm in fold_metrics if k in fm])) for k in fold_metrics[0].keys()}

        model.fit(X, y)
        model_path = registry.save_model(model, name, version)

        metadata = {
            "symbols": symbols,
            "date_range": [str(df["date"].min()), str(df["date"].max())],
            "feature_list": feature_cols,
            "metrics": mean_metrics,
            "target": target_col,
            "dataset_path": str(dataset_path),
            "pretrain_ingest_summary": ingest_summary,
            "pretrain_refresh_skipped_symbols": fresh_symbols if refresh_prices else [],
        }
        metadata_path = registry.save_metadata(name, version, metadata)
        results[name] = {
            "metrics": mean_metrics,
            "model_path": str(model_path),
            "metadata_path": str(metadata_path),
        }

    leaderboard_path = settings.output_dir / f"training_results_{version}.json"
    leaderboard_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbols", nargs="+", required=False)
    parser.add_argument("--horizon-days", type=int, default=1)
    args = parser.parse_args()

    settings = get_settings()
    symbols = args.symbols or settings.default_symbols
    results = train_models(symbols=symbols, horizon_days=args.horizon_days)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
