from datetime import datetime

from app.models.schemas import PredictResponse


def test_prediction_response_schema_parses():
    payload = {
        "generated_at": datetime.utcnow().isoformat(),
        "predictions": [
            {
                "symbol": "NVDA",
                "prob_up": 0.71,
                "predicted_return": 0.014,
                "confidence": 0.71,
                "latest_sentiment": 0.28,
                "decision": "BUY_CANDIDATE",
            }
        ],
    }
    obj = PredictResponse(**payload)
    assert obj.predictions[0].symbol == "NVDA"
