import pandas as pd

from src.features.technical import build_technical_features


def test_build_technical_features_basic_columns():
    df = pd.DataFrame(
        {
            "date": pd.date_range("2024-01-01", periods=260, freq="D"),
            "open": 100.0,
            "high": 101.0,
            "low": 99.0,
            "close": range(260),
            "volume": 1000,
            "symbol": "AAPL",
        }
    )
    spy = df.copy()
    spy["symbol"] = "SPY"
    inp = pd.concat([df, spy], ignore_index=True)

    out = build_technical_features(inp)
    for col in ["rsi_14", "macd", "sma_20", "relative_return_1d", "day_of_week"]:
        assert col in out.columns
