import pandas as pd

from src.training.train import _select_features


def test_select_features_excludes_targets_and_ids():
    df = pd.DataFrame(
        {
            "date": pd.date_range("2024-01-01", periods=3),
            "symbol": ["AAPL", "AAPL", "AAPL"],
            "f1": [1.0, 2.0, 3.0],
            "target_up_1d": [0, 1, 1],
            "target_return_1d": [0.1, 0.2, -0.1],
        }
    )
    cols = _select_features(df)
    assert cols == ["f1"]
