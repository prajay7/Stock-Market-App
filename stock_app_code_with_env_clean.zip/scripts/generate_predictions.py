from app.core.config import get_settings
from src.inference.predict import predict_for_symbols


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--symbols", nargs="+", required=False)
    parser.add_argument("--horizon-days", type=int, default=1)
    parser.add_argument("--model-name", default="hist_gb_classifier")
    args = parser.parse_args()

    settings = get_settings()
    symbols = args.symbols or settings.default_symbols
    print(predict_for_symbols(symbols, args.model_name, args.horizon_days).to_json(orient="records", indent=2))
