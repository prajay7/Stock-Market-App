from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from app.core.config import get_settings
from app.services.automation_service import automation_service


def _to_dataframe(rows: list[dict]) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows)


def _format_dt(value) -> str:
    if value is None:
        return "N/A"
    ts = pd.to_datetime(value, errors="coerce")
    if pd.isna(ts):
        return str(value)
    return ts.strftime("%Y-%m-%d %H:%M:%S UTC")


def _source_breakdown_df(breakdown: dict) -> pd.DataFrame:
    if not isinstance(breakdown, dict):
        return pd.DataFrame()
    rows = [
        {"Source": "defaults", "Count": int(breakdown.get("defaults_count", 0))},
        {"Source": "global", "Count": int(breakdown.get("global_count", 0))},
        {"Source": "sec_list", "Count": int(breakdown.get("sec_list_count", 0))},
        {"Source": "news", "Count": int(breakdown.get("news_count", 0))},
        {"Source": "combined_unique", "Count": int(breakdown.get("combined_unique_count", 0))},
        {"Source": "final_selected", "Count": int(breakdown.get("final_selected_count", 0))},
    ]
    return pd.DataFrame(rows)


def _historical_source_breakdown_df(breakdown: dict) -> pd.DataFrame:
    if not isinstance(breakdown, dict) or not breakdown:
        return pd.DataFrame()
    rows = [{"Source": str(source), "Count": int(count)} for source, count in breakdown.items()]
    out = pd.DataFrame(rows)
    return out.sort_values("Count", ascending=False).reset_index(drop=True)


def _upsert_env_values(env_path: Path, updates: dict[str, str]) -> bool:
    if not env_path.exists():
        return False

    lines = env_path.read_text(encoding="utf-8").splitlines()
    seen: set[str] = set()
    out_lines: list[str] = []

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in line:
            out_lines.append(line)
            continue

        key = line.split("=", 1)[0].strip()
        if key in updates:
            out_lines.append(f"{key}={updates[key]}")
            seen.add(key)
        else:
            out_lines.append(line)

    for key, value in updates.items():
        if key not in seen:
            out_lines.append(f"{key}={value}")

    env_path.write_text("\n".join(out_lines) + "\n", encoding="utf-8")
    return True


def render_automation_monitor() -> None:
    settings = get_settings()

    st.header("Automation Monitor")
    st.caption("Track last auto-run, inspect top suggestions, source mix, and trigger override runs.")

    st.subheader("Quick Switches")
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        model_override = st.selectbox(
            "Prediction model",
            options=["auto", "hist_gb_classifier", "rf_classifier", "log_reg_classifier", "openai_stock_llm"],
            index=["auto", "hist_gb_classifier", "rf_classifier", "log_reg_classifier", "openai_stock_llm"].index(
                str(settings.automation_prediction_model or "auto")
                if str(settings.automation_prediction_model or "auto") in {"auto", "hist_gb_classifier", "rf_classifier", "log_reg_classifier", "openai_stock_llm"}
                else "auto"
            ),
            key="automation_model_override",
        )
    with col2:
        interval_override = st.number_input(
            "Interval (minutes)",
            min_value=1,
            max_value=1440,
            value=int(settings.automation_interval_minutes),
            step=1,
            key="automation_interval_override",
        )
    with col3:
        run_now = st.button("Run Now", use_container_width=True)

    save_defaults = st.button("Save Defaults To .env", use_container_width=True)

    if save_defaults:
        env_path = Path(".env")
        ok = _upsert_env_values(
            env_path,
            {
                "AUTOMATION_PREDICTION_MODEL": str(model_override),
                "AUTOMATION_INTERVAL_MINUTES": str(int(interval_override)),
            },
        )
        if ok:
            st.success("Saved defaults to .env. Restart FastAPI/Streamlit to apply scheduler interval updates.")
        else:
            st.error("Could not find .env file to update.")

    if run_now:
        with st.spinner("Running automation cycle..."):
            result = automation_service.run_cycle(
                model_override=model_override if model_override != "auto" else None,
                interval_minutes_override=int(interval_override),
            )
        st.success(
            f"Run complete | status={result.get('status')} | predictions={result.get('predictions_count', 0)} | top={len(result.get('top_suggestions', []))}"
        )

    latest = automation_service.latest()

    st.subheader("Last Run Status/Time")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Status", str(latest.get("status", "unknown")))
    m2.metric("Started", _format_dt(latest.get("started_at")))
    m3.metric("Completed", _format_dt(latest.get("completed_at")))
    m4.metric("Model", str(latest.get("prediction_model", "n/a")))

    st.caption(f"Configured/last interval: {latest.get('interval_minutes', 'n/a')} minute(s)")

    st.subheader("Source Breakdown")
    breakdown_df = _source_breakdown_df(latest.get("source_breakdown", {}))
    if breakdown_df.empty:
        st.info("No source breakdown available yet.")
    else:
        st.dataframe(breakdown_df, use_container_width=True, hide_index=True)

    st.subheader("Historical Ingest Source Breakdown")
    historical_df = _historical_source_breakdown_df(latest.get("historical_source_breakdown", {}))
    if historical_df.empty:
        st.info("No historical source usage available yet.")
    else:
        st.dataframe(historical_df, use_container_width=True, hide_index=True)

    ingest_summary = latest.get("historical_ingest_summary", {})
    if isinstance(ingest_summary, dict) and ingest_summary:
        c1, c2 = st.columns(2)
        c1.metric("Symbols With Rows", int(ingest_summary.get("symbols_with_rows", 0)))
        c2.metric("Symbols Without Rows", int(ingest_summary.get("symbols_without_rows", 0)))

    st.subheader("Top Suggestions Table")
    top_df = _to_dataframe(latest.get("top_suggestions", []))
    if top_df.empty:
        st.info("No suggestions available yet. Run automation cycle from above.")
    else:
        preferred = [
            "symbol",
            "blended_score",
            "confidence",
            "predicted_return",
            "decision",
            "news_opportunity_score",
            "target_price",
            "stop_loss_price",
            "current_price",
        ]
        cols = [col for col in preferred if col in top_df.columns] + [col for col in top_df.columns if col not in preferred]
        st.dataframe(top_df[cols], use_container_width=True, height=360)
