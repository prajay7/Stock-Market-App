from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

from src.inference.predict import predict_for_symbols


def _color_diff(val):
    try:
        v = float(val)
    except Exception:
        return ""
    if pd.isna(v):
        return ""
    if v > 0:
        return "background-color: #e6f7ea; color: #0f5c2e;"
    if v < 0:
        return "background-color: #fdeaea; color: #8a1f1f;"
    return "background-color: #f3f4f6; color: #374151;"


def _all_trained_symbols(model_dir, model_name: str) -> list[str]:
    symbols: set[str] = set()
    for path in sorted(model_dir.glob(f"{model_name}_*.metadata.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        for symbol in payload.get("symbols", []):
            if symbol:
                symbols.add(str(symbol))
    return sorted(symbols)


def _trained_symbols_by_latest_training(model_dir, model_name: str) -> list[str]:
    latest_by_symbol: dict[str, pd.Timestamp] = {}
    for path in sorted(model_dir.glob(f"{model_name}_*.metadata.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue

        saved_at_raw = payload.get("saved_at")
        saved_at = pd.to_datetime(saved_at_raw, errors="coerce")
        if pd.isna(saved_at):
            saved_at = pd.Timestamp.min

        for symbol in payload.get("symbols", []):
            if not symbol:
                continue
            symbol_str = str(symbol)
            current = latest_by_symbol.get(symbol_str)
            if current is None or saved_at > current:
                latest_by_symbol[symbol_str] = saved_at

    ordered = sorted(latest_by_symbol.items(), key=lambda x: x[1], reverse=True)
    return [symbol for symbol, _ in ordered]


def _sec_list_symbols(path: str = "sec_list.csv") -> list[str]:
    try:
        csv_path = Path(path)
        if not csv_path.exists():
            return []
        df = pd.read_csv(csv_path)
        if "Symbol" not in df.columns:
            return []
        symbols = [str(sym).strip().upper() for sym in df["Symbol"].tolist() if str(sym).strip()]
        return sorted(list(dict.fromkeys(symbols)))
    except Exception:
        return []


def render_predictions(settings) -> None:
    st.subheader("Top Predictions")

    openai_model_name = "openai_stock_llm"

    model_name = st.selectbox(
        "Model",
        options=["hist_gb_classifier", "rf_classifier", "log_reg_classifier", "xgboost_classifier", openai_model_name],
        key="pred_model_name",
    )
    horizon_days = st.number_input("Horizon days", min_value=1, max_value=10, value=1, step=1, key="pred_horizon_days")
    atr_multiplier = st.slider(
        "Stop-loss ATR multiplier",
        min_value=0.25,
        max_value=3.0,
        value=1.0,
        step=0.25,
        key="pred_atr_multiplier",
    )
    include_live_quote = st.checkbox(
        "Fetch live quote/time from Alpha Vantage (slower)",
        value=True,
        key="pred_include_live_quote",
    )

    if model_name == openai_model_name:
        trained_symbols = sorted({str(sym).strip().upper() for sym in settings.default_symbols if str(sym).strip()})
        trained_symbols_by_latest = trained_symbols
        st.caption(f"OpenAI predictor universe size: {len(trained_symbols)} symbol(s) from DEFAULT_SYMBOLS.")
        if not settings.openai_predict_enabled:
            st.warning("OpenAI predictor is disabled. Set OPENAI_PREDICT_ENABLED=true in environment.")
    else:
        trained_symbols = _all_trained_symbols(settings.model_dir, model_name)
        trained_symbols_by_latest = _trained_symbols_by_latest_training(settings.model_dir, model_name)
        if not trained_symbols_by_latest:
            trained_symbols_by_latest = trained_symbols
        st.caption(f"Trained symbols available for {model_name}: {len(trained_symbols)}")

    st.markdown("### Symbol Universe")
    universe_source = st.radio(
        "Prediction symbols source",
        ["Configured defaults", "From sec_list.csv", "Custom symbols"],
        horizontal=True,
        key="pred_universe_source",
    )

    selected_symbols: list[str] = []
    if universe_source == "Configured defaults":
        selected_symbols = [str(sym).strip().upper() for sym in settings.default_symbols if str(sym).strip()]
    elif universe_source == "From sec_list.csv":
        sec_symbols = _sec_list_symbols("sec_list.csv")
        max_from_sec = st.number_input("Max symbols from sec_list.csv", min_value=1, max_value=2000, value=50, step=1, key="pred_max_from_sec_list")
        selected_symbols = sec_symbols[: int(max_from_sec)]
        st.caption(f"Loaded {len(sec_symbols)} symbols from sec_list.csv. Using first {len(selected_symbols)}.")
    else:
        raw_custom = st.text_area(
            "Custom symbols (comma or newline separated)",
            value="\n".join(settings.default_symbols[:6]),
            key="pred_custom_symbols",
            height=120,
        )
        parts = [part.strip().upper() for part in raw_custom.replace("\n", ",").split(",")]
        selected_symbols = [part for part in parts if part]

    selected_symbols = sorted(list(dict.fromkeys(selected_symbols)))
    st.caption(f"Selected symbols for prediction: {len(selected_symbols)}")

    if model_name != openai_model_name:
        trained_set = set(trained_symbols)
        selected_symbols = [sym for sym in selected_symbols if sym in trained_set]
        st.caption(f"After trained-symbol filter: {len(selected_symbols)}")

    auto_run = st.checkbox("Auto-generate on page load", value=False, key="pred_auto_run")
    max_symbols = st.number_input("Auto-run max symbols", min_value=1, max_value=200, value=10, step=1, key="pred_max_symbols")

    auto_run_key = (
        f"predictions-auto-run-done-{model_name}-{int(horizon_days)}-"
        f"{float(atr_multiplier):.2f}-{int(include_live_quote)}"
    )
    if auto_run and selected_symbols and not st.session_state.get(auto_run_key, False):
        try:
            with st.spinner(f"Auto-generating predictions for up to {int(max_symbols)} symbols..."):
                target_symbols = selected_symbols[: int(max_symbols)]
                pred_df = predict_for_symbols(
                    symbols=target_symbols,
                    model_name=model_name,
                    horizon_days=int(horizon_days),
                    atr_multiplier=float(atr_multiplier),
                    include_live_quote=bool(include_live_quote),
                )
            st.session_state[auto_run_key] = True
            st.success(f"Auto-generated predictions for {len(pred_df)} stock(s) (limit {int(max_symbols)}).")
            st.cache_data.clear()
            st.rerun()
        except Exception as exc:
            st.error(f"Auto-generation failed: {exc}")

    if not auto_run:
        st.session_state[auto_run_key] = False

    if st.button("Generate Predictions For Selected Symbols", disabled=not selected_symbols):
        try:
            with st.spinner("Generating predictions for selected symbols..."):
                pred_df = predict_for_symbols(
                    symbols=selected_symbols,
                    model_name=model_name,
                    horizon_days=int(horizon_days),
                    atr_multiplier=float(atr_multiplier),
                    include_live_quote=bool(include_live_quote),
                )
            st.success(f"Generated predictions for {len(pred_df)} stock(s).")
            st.cache_data.clear()
            st.rerun()
        except Exception as exc:
            st.error(f"Failed to generate predictions: {exc}")

    pred_path = settings.output_dir / "latest_predictions.parquet"
    if pred_path.exists():
        pred_df = pd.read_parquet(pred_path).sort_values("confidence", ascending=False)
        if {"current_price", "live_price"}.issubset(set(pred_df.columns)):
            model_px = pd.to_numeric(pred_df["current_price"], errors="coerce")
            live_px = pd.to_numeric(pred_df["live_price"], errors="coerce")
            pred_df["live_vs_model_abs"] = live_px - model_px
            pred_df["live_vs_model_pct"] = ((live_px - model_px) / model_px.replace(0, pd.NA)) * 100.0
        st.caption(f"Currently loaded predictions: {len(pred_df)} stock(s)")
        if "price_as_of" in pred_df.columns:
            latest_as_of = pred_df["price_as_of"].dropna().astype(str).max()
            if latest_as_of:
                st.caption(f"Price source: latest ingested daily close (not live tick). Latest as-of date: {latest_as_of}")
                st.caption("For daily interval (1d), time may appear as 00:00:00 from provider candle timestamp.")
        if "live_price" in pred_df.columns and pred_df["live_price"].notna().any():
            st.caption("Live quote/time columns are best-effort via Alpha Vantage and may be delayed/unavailable for some symbols.")
        preferred = [
            "symbol",
            "price_as_of",
            "price_as_of_time",
            "current_price",
            "live_price",
            "live_vs_model_abs",
            "live_vs_model_pct",
            "live_price_as_of",
            "live_price_as_of_time",
            "live_price_source",
            "target_price",
            "stop_loss_price",
            "confidence",
            "prob_up",
            "predicted_return",
            "latest_sentiment",
            "decision",
        ]
        cols = [c for c in preferred if c in pred_df.columns] + [c for c in pred_df.columns if c not in preferred]
        display_df = pred_df[cols]
        if {"live_vs_model_abs", "live_vs_model_pct"}.issubset(set(display_df.columns)):
            show_only_large_mismatch = st.checkbox(
                "Show only large mismatch rows",
                value=False,
                key="pred_show_only_large_mismatch",
            )
            mismatch_threshold_pct = st.number_input(
                "Mismatch threshold (%)",
                min_value=0.1,
                max_value=50.0,
                value=1.0,
                step=0.1,
                key="pred_mismatch_threshold_pct",
            )
            if show_only_large_mismatch:
                pct_series = pd.to_numeric(display_df["live_vs_model_pct"], errors="coerce").abs()
                display_df = display_df[pct_series >= float(mismatch_threshold_pct)]
                st.caption(f"Filtered rows: {len(display_df)} stock(s) with mismatch >= {float(mismatch_threshold_pct):.1f}%")
            styled = display_df.style.format(
                {
                    "live_vs_model_abs": "{:+.2f}",
                    "live_vs_model_pct": "{:+.2f}%",
                }
            )
            styled = styled.map(_color_diff, subset=["live_vs_model_abs", "live_vs_model_pct"])
            st.dataframe(styled, use_container_width=True)
        else:
            st.dataframe(display_df, use_container_width=True)
    else:
        st.info("No predictions yet. Use the button above to generate predictions for all trained stocks.")
