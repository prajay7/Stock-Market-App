from __future__ import annotations

import pandas as pd
import streamlit as st


def render_news(settings, status_merged: pd.DataFrame, filter_universe, decorate_status) -> None:
    st.subheader("News And Symbol Detail")
    filtered = decorate_status(filter_universe(status_merged, "news"))
    detail_options = filtered["train_symbol"].dropna().tolist() if not filtered.empty else settings.default_symbols
    selected_key = "news_selected_symbol"
    qp_key = "news_selected_symbol"
    qp_selected = str(st.query_params.get(qp_key, "")).strip()
    if selected_key not in st.session_state:
        st.session_state[selected_key] = qp_selected if qp_selected in detail_options else detail_options[0]
    if st.session_state[selected_key] not in detail_options:
        st.session_state[selected_key] = detail_options[0]
    selected = st.selectbox("Select symbol", options=detail_options, key=selected_key)
    st.query_params[qp_key] = str(selected)
    news_path = settings.raw_data_dir / "news" / f"{selected}.parquet"

    if news_path.exists():
        news = pd.read_parquet(news_path).sort_values("published_at", ascending=False).head(30)
        cols = [c for c in ["published_at", "source", "title", "sentiment_score", "relevance_score", "url"] if c in news.columns]
        st.dataframe(news[cols], use_container_width=True, height=420)
    else:
        st.warning("No related news found for this symbol yet.")
