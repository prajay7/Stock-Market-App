from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
from app.core.config import get_settings
from src.data.historical_loader import HistoricalLoader
from src.data.news_loader import AlphaVantageNewsLoader
from src.data.web_news_scraper import WebsiteNewsScraper, build_common_news_sources
from src.inference.predict import predict_for_symbols
from src.training.train import train_models
from src.utils.symbols import map_symbol_for_market
from src.utils.unsupported_symbols import get_unsupported_symbols, mark_failure, mark_success
from dashboard.views import (
    render_automation_monitor,
    render_backtest,
    render_news,
    render_news_impact,
    render_overview,
    render_predictions,
    render_queue,
    render_paper_trading,
    render_signal_backtesting,
    render_training,
    render_watchlists_and_alerts,
)
from dashboard.training_queue import (
    create_job,
    cancel_jobs_by_symbols,
    enqueue_job,
    enqueue_jobs,
    get_job,
    get_jobs,
    latest_job_for_symbol,
    queue_status_for_symbol,
    reset_queue,
    restore_checkpoint,
    start_worker,
    update_job,
)

settings = get_settings()
bulk_plan_path = settings.output_dir / "checkpoints" / "dashboard_bulk_training.json"
common_source_selection_path = settings.output_dir / "checkpoints" / "common_news_source_selection.json"
website_scrape_url_path = settings.output_dir / "checkpoints" / "website_scrape_url.json"
unsupported_path = settings.output_dir / "checkpoints" / "unsupported_symbols.json"
unsupported_failure_threshold = 2
NEWS_SCRAPE_LOCK = threading.Lock()
NEWS_SCRAPE_JOBS: dict[str, dict] = {}


def _load_bulk_plan() -> dict | None:
    if not bulk_plan_path.exists():
        return None
    try:
        return json.loads(bulk_plan_path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _save_bulk_plan(payload: dict) -> None:
    bulk_plan_path.parent.mkdir(parents=True, exist_ok=True)
    bulk_plan_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _load_common_source_selection() -> dict[str, list[str]]:
    if not common_source_selection_path.exists():
        return {}
    try:
        payload = json.loads(common_source_selection_path.read_text(encoding="utf-8"))
    except Exception:
        return {}

    if not isinstance(payload, dict):
        return {}

    selections: dict[str, list[str]] = {}
    for symbol, labels in payload.items():
        if not isinstance(symbol, str) or not isinstance(labels, list):
            continue
        selections[symbol] = [str(label) for label in labels if str(label).strip()]
    return selections


def _save_common_source_selection(payload: dict[str, list[str]]) -> None:
    common_source_selection_path.parent.mkdir(parents=True, exist_ok=True)
    common_source_selection_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _load_website_scrape_urls() -> dict[str, str]:
    if not website_scrape_url_path.exists():
        return {}
    try:
        payload = json.loads(website_scrape_url_path.read_text(encoding="utf-8"))
    except Exception:
        return {}

    if not isinstance(payload, dict):
        return {}

    urls: dict[str, str] = {}
    for symbol, url in payload.items():
        if not isinstance(symbol, str) or not isinstance(url, str):
            continue
        cleaned = url.strip()
        if cleaned:
            urls[symbol] = cleaned
    return urls


def _save_website_scrape_urls(payload: dict[str, str]) -> None:
    website_scrape_url_path.parent.mkdir(parents=True, exist_ok=True)
    website_scrape_url_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _latest_news_scrape_job(symbol: str) -> dict | None:
    with NEWS_SCRAPE_LOCK:
        jobs = [job.copy() for job in NEWS_SCRAPE_JOBS.values() if str(job.get("symbol")) == str(symbol)]
    if not jobs:
        return None
    jobs.sort(key=lambda job: str(job.get("finished_at") or job.get("created_at") or ""))
    return jobs[-1]


def _is_news_scrape_running(symbol: str) -> bool:
    job = _latest_news_scrape_job(symbol)
    return bool(job and str(job.get("status")) == "running")


def _start_news_scrape_job(symbol: str, mode: str, payload: dict) -> str:
    running_job = _latest_news_scrape_job(symbol)
    if running_job and str(running_job.get("status")) == "running":
        return str(running_job["job_id"])

    job_id = str(uuid.uuid4())[:8]
    job = {
        "job_id": job_id,
        "symbol": str(symbol),
        "mode": str(mode),
        "status": "running",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "finished_at": None,
        "message": "Scraping headlines",
        "result": None,
        "payload": payload,
    }
    with NEWS_SCRAPE_LOCK:
        NEWS_SCRAPE_JOBS[job_id] = job

    def _worker() -> None:
        try:
            scraper = WebsiteNewsScraper(settings.raw_data_dir, database_url=settings.database_url)
            if mode == "common":
                sources = payload.get("sources", [])
                limit_per_source = int(payload.get("limit_per_source", 10))
                scraped_df = scraper.ingest_many(sources, symbol=symbol, limit_per_source=limit_per_source)
            else:
                target_url = str(payload.get("target_url") or "")
                limit = int(payload.get("limit", 20))
                scraped_df = scraper.ingest(target_url, symbol=symbol, limit=limit)

            row_count = int(len(scraped_df)) if scraped_df is not None else 0
            source_count = 0
            if scraped_df is not None and not scraped_df.empty and "source" in scraped_df.columns:
                source_count = len({str(value) for value in scraped_df["source"].dropna().tolist() if str(value).strip()})

            with NEWS_SCRAPE_LOCK:
                NEWS_SCRAPE_JOBS[job_id].update(
                    {
                        "status": "completed",
                        "finished_at": datetime.now().isoformat(timespec="seconds"),
                        "message": "Scrape completed" if row_count > 0 else "No usable headlines found",
                        "result": {"rows": row_count, "source_count": source_count},
                    }
                )
        except Exception as exc:
            with NEWS_SCRAPE_LOCK:
                NEWS_SCRAPE_JOBS[job_id].update(
                    {
                        "status": "failed",
                        "finished_at": datetime.now().isoformat(timespec="seconds"),
                        "message": str(exc),
                        "result": None,
                    }
                )

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    return job_id


def _bulk_plan_summary() -> dict:
    plan = _load_bulk_plan() or {}
    symbols = [str(s) for s in plan.get("symbols", [])]
    cursor = int(plan.get("cursor", 0))
    total = len(symbols)
    remaining = max(0, total - cursor)
    resume_state = "No bulk plan"
    if plan:
        if plan.get("completed"):
            resume_state = "Completed"
        elif plan.get("canceled_at"):
            resume_state = "Canceled"
        elif cursor > 0:
            resume_state = "Paused / Resume available"
        else:
            resume_state = "Queued"
    return {
        "plan": plan,
        "cursor": cursor,
        "total": total,
        "remaining": remaining,
        "resume_state": resume_state,
    }


def _enqueue_next_bulk_batch() -> None:
    plan = _load_bulk_plan()
    if not plan or plan.get("completed"):
        return
    if get_jobs():
        return

    symbols = [str(s) for s in plan.get("symbols", [])]
    unsupported = get_unsupported_symbols(unsupported_path)
    symbols = [s for s in symbols if s not in unsupported]
    cursor = int(plan.get("cursor", 0))
    batch_size = max(1, int(plan.get("batch_size", 25)))
    lookback_days = int(plan.get("lookback_days", 365))
    horizon_days = int(plan.get("horizon_days", 1))
    direct_internet_scrape = bool(plan.get("direct_internet_scrape", False))

    remaining = symbols[cursor:]
    if not remaining:
        plan["completed"] = True
        plan["finished_at"] = datetime.now().isoformat(timespec="seconds")
        _save_bulk_plan(plan)
        return

    batch = remaining[:batch_size]
    enqueue_bulk_training_jobs(batch, lookback_days, horizon_days, direct_internet_scrape=direct_internet_scrape)
    plan["cursor"] = cursor + len(batch)
    plan["last_enqueued_at"] = datetime.now().isoformat(timespec="seconds")
    plan["completed"] = plan["cursor"] >= len(symbols)
    _save_bulk_plan(plan)


def _resume_bulk_plan() -> None:
    plan = _load_bulk_plan()
    if not plan:
        return
    if plan.get("completed") or plan.get("canceled_at"):
        return
    _enqueue_next_bulk_batch()


def _run_background_training(job: dict) -> None:
    symbol = str(job["symbol"])
    try:
        if symbol in get_unsupported_symbols(unsupported_path):
            update_job(
                str(job["job_id"]),
                status="failed",
                finished_at=datetime.now().isoformat(timespec="seconds"),
                message="Auto-skipped: symbol is marked unsupported due repeated no-data failures.",
            )
            return

        loader = HistoricalLoader(
            settings.raw_data_dir,
            alpha_vantage_api_key=settings.alpha_vantage_api_key,
            stooq_api_key=settings.stooq_api_key,
        )
        prefer_direct = bool(job.get("direct_internet_scrape", False))
        ingest_summary = loader.ingest(
            [symbol],
            interval=settings.historical_interval,
            lookback_days=int(job["lookback_days"]),
            direct_internet_scrape=prefer_direct,
            save_failure_snapshot=True,
        )
        rows = int(ingest_summary.get(symbol, 0))
        first_diag = str(loader.last_diagnostics.get(symbol, "")).strip()

        # If standard provider path fails, immediately retry with direct internet mode.
        if rows == 0 and not prefer_direct:
            ingest_summary_retry = loader.ingest(
                [symbol],
                interval=settings.historical_interval,
                lookback_days=int(job["lookback_days"]),
                direct_internet_scrape=True,
                save_failure_snapshot=True,
            )
            retry_rows = int(ingest_summary_retry.get(symbol, 0))
            if retry_rows > 0:
                rows = retry_rows
                update_job(
                    str(job["job_id"]),
                    message=f"Recovered via direct internet scrape for {symbol}; continuing training",
                )

        if rows == 0:
            diag = str(loader.last_diagnostics.get(symbol, "")).strip()
            if first_diag:
                diag = f"standard_mode:[{first_diag}] | direct_mode:[{diag or 'no provider data'}]"
            meta = mark_failure(
                unsupported_path,
                symbol,
                reason=f"No historical rows ingested for selected stock. Diagnostics: {diag or 'no provider data'}",
                failure_threshold=unsupported_failure_threshold,
            )
            if bool(meta.get("unsupported", False)):
                raise ValueError(
                    (
                        "No historical rows ingested for selected stock. "
                        f"Diagnostics: {diag or 'no provider data'}. "
                        "Symbol is now marked unsupported and will be auto-skipped in bulk mode."
                    )
                )
            raise ValueError(
                "No historical rows ingested for selected stock. "
                f"Diagnostics: {diag or 'no provider data'}. "
                "Try again later if provider is rate-limited."
            )

        mark_success(unsupported_path, symbol)

        train_result = train_models([symbol], horizon_days=int(job["horizon_days"]), refresh_prices=False)
        pred_df = predict_for_symbols([symbol], model_name="hist_gb_classifier", horizon_days=int(job["horizon_days"]))

        update_job(
            str(job["job_id"]),
            status="completed",
            finished_at=datetime.now().isoformat(timespec="seconds"),
            message=f"Training completed for {symbol}",
            result={
                "ingest_rows": rows,
                "train_result": train_result,
                "prediction": pred_df.to_dict(orient="records"),
            },
        )
        st.cache_data.clear()
    except Exception as exc:
        update_job(
            str(job["job_id"]),
            status="failed",
            finished_at=datetime.now().isoformat(timespec="seconds"),
            message=str(exc),
        )


def enqueue_training_job(symbol: str, lookback_days: int, horizon_days: int, direct_internet_scrape: bool = False) -> str:
    job = create_job(symbol, lookback_days, horizon_days, direct_internet_scrape=direct_internet_scrape)
    job_id = enqueue_job(job)
    start_worker(_run_background_training)
    return job_id


def enqueue_bulk_training_jobs(
    symbols: list[str],
    lookback_days: int,
    horizon_days: int,
    direct_internet_scrape: bool = False,
) -> list[str]:
    jobs = [create_job(symbol, lookback_days, horizon_days, direct_internet_scrape=direct_internet_scrape) for symbol in symbols]
    job_ids = enqueue_jobs(jobs)
    start_worker(_run_background_training)
    return job_ids


def status_badge(status: str) -> str:
    mapping = {
        "Never Trained": "⚪ Never Trained",
        "In Progress": "🟡 In Progress",
        "Trained": "🟢 Trained",
        "Failed": "🔴 Failed",
        "Canceled": "⚫ Canceled",
    }
    return mapping.get(status, status)


def last_failure_reason(symbol: str) -> str:
    job = latest_job_for_symbol(symbol)
    if not job or str(job.get("status")) != "failed":
        return ""
    return str(job.get("message") or "")


def bulk_enqueue_with_checkpoint(
    symbols: list[str],
    lookback_days: int,
    horizon_days: int,
    batch_size: int,
    direct_internet_scrape: bool = False,
) -> list[str]:
    unsupported = get_unsupported_symbols(unsupported_path)
    remaining = []
    for symbol in symbols:
        if symbol in unsupported:
            continue
        if queue_status_for_symbol(symbol) in {"Never Trained", "Failed"}:
            remaining.append(symbol)

    payload = {
        "symbols": remaining,
        "lookback_days": int(lookback_days),
        "horizon_days": int(horizon_days),
        "batch_size": int(batch_size),
        "direct_internet_scrape": bool(direct_internet_scrape),
        "cursor": 0,
        "completed": False,
        "saved_at": datetime.now().isoformat(timespec="seconds"),
    }
    _save_bulk_plan(payload)
    _enqueue_next_bulk_batch()
    return [job["job_id"] for job in get_jobs()]


@st.cache_data(ttl=60)
def load_symbol_universe(csv_path: str) -> pd.DataFrame:
    path = Path(csv_path)
    if not path.exists():
        return pd.DataFrame(
            {
                "symbol": settings.default_symbols,
                "series": "DEFAULT",
                "security_name": settings.default_symbols,
                "train_symbol": settings.default_symbols,
            }
        )

    df = pd.read_csv(path)
    if "Symbol" not in df.columns:
        return pd.DataFrame(
            {
                "symbol": settings.default_symbols,
                "series": "DEFAULT",
                "security_name": settings.default_symbols,
                "train_symbol": settings.default_symbols,
            }
        )

    out = pd.DataFrame()
    out["symbol"] = df["Symbol"].astype(str).str.upper().str.strip()
    out["series"] = df["Series"].astype(str).str.upper().str.strip() if "Series" in df.columns else "UNKNOWN"
    out["security_name"] = df["Security Name"].astype(str) if "Security Name" in df.columns else out["symbol"]
    out = out[out["symbol"] != ""]
    out = out.drop_duplicates(subset=["symbol"])
    out["train_symbol"] = out["symbol"].apply(lambda x: map_symbol_for_market(x, market="india"))
    return out.reset_index(drop=True)


@st.cache_data(ttl=2)
def load_training_status(model_dir: str) -> pd.DataFrame:
    rows: list[dict] = []
    for path in Path(model_dir).glob("*.metadata.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            trained_at = payload.get("saved_at")
            model_name = payload.get("model_name")
            version = payload.get("version")
            metrics = payload.get("metrics", {})
            roc_auc = metrics.get("roc_auc")
            for symbol in payload.get("symbols", []):
                rows.append(
                    {
                        "train_symbol": str(symbol),
                        "last_trained_at": trained_at,
                        "last_model_name": model_name,
                        "last_model_version": version,
                        "last_roc_auc": roc_auc,
                    }
                )
        except Exception:
            continue

    if not rows:
        return pd.DataFrame(columns=["train_symbol", "last_trained_at", "last_model_name", "last_model_version", "last_roc_auc"])

    status = pd.DataFrame(rows)
    status["last_trained_at"] = pd.to_datetime(status["last_trained_at"], errors="coerce")
    status = status.sort_values("last_trained_at", ascending=False).drop_duplicates(subset=["train_symbol"], keep="first")
    return status.reset_index(drop=True)


def render_app(forced_page: str | None = None, show_page_picker: bool = True) -> None:
    restore_checkpoint()
    if get_jobs():
        start_worker(_run_background_training)
    else:
        _enqueue_next_bulk_batch()

    pages = ["Watchlists & Alerts", "Paper Trading & Journal", "Automation Monitor"]

    st.set_page_config(page_title="Stock AI Platform", layout="wide")
    st.title("Stock AI Platform Dashboard")
    st.caption("Educational use only. Not financial advice.")

    if forced_page is not None:
        page = forced_page
        if show_page_picker:
            st.sidebar.caption(f"Current page: {forced_page}")
    else:
        if "current_page" not in st.session_state:
            st.session_state["current_page"] = "Watchlists & Alerts"

        if show_page_picker:
            st.sidebar.subheader("Pages")
            for page_name in pages:
                button_type = "primary" if st.session_state["current_page"] == page_name else "secondary"
                if st.sidebar.button(page_name, key=f"nav_{page_name}", use_container_width=True, type=button_type):
                    st.session_state["current_page"] = page_name

        page = st.session_state["current_page"]

    universe = load_symbol_universe("sec_list.csv")
    status_df = load_training_status(str(settings.model_dir))
    status_merged = universe.merge(status_df, on="train_symbol", how="left")
    unsupported_symbols = get_unsupported_symbols(unsupported_path)


    def _filter_universe(df: pd.DataFrame, key_prefix: str) -> pd.DataFrame:
        search_key = f"{key_prefix}-search"
        series_key = f"{key_prefix}-series"
        qp_search_key = f"{key_prefix}_search"
        qp_series_key = f"{key_prefix}_series"

        series_options = sorted(df["series"].dropna().unique().tolist())
        default_series = ["EQ"] if "EQ" in series_options else []

        if search_key not in st.session_state:
            st.session_state[search_key] = str(st.query_params.get(qp_search_key, ""))
        if series_key not in st.session_state:
            raw_series = str(st.query_params.get(qp_series_key, "")).strip()
            parsed = [s for s in raw_series.split(",") if s] if raw_series else []
            st.session_state[series_key] = [s for s in parsed if s in series_options] or default_series

        search = st.text_input("Search symbol or company", key=search_key)
        series_filter = st.multiselect(
            "Series filter",
            options=series_options,
            key=series_key,
        )

        st.query_params[qp_search_key] = search
        st.query_params[qp_series_key] = ",".join(series_filter)

        out = df.copy()
        if search.strip():
            q = search.strip().lower()
            out = out[out["symbol"].str.lower().str.contains(q, na=False) | out["security_name"].str.lower().str.contains(q, na=False)]
        if series_filter:
            out = out[out["series"].isin(series_filter)]
        return out


    def _decorate_status(df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        out["queue_status"] = out["train_symbol"].apply(queue_status_for_symbol)
        out["status_badge"] = out["queue_status"].apply(status_badge)
        out["last_failure_reason"] = out["train_symbol"].apply(last_failure_reason)
        out["unsupported"] = out["train_symbol"].isin(unsupported_symbols)
        return out


    plan_summary = _bulk_plan_summary()
    plan = plan_summary["plan"]
    queue_jobs = get_jobs()
    queued_count = sum(1 for job in queue_jobs if job["status"] == "queued")
    running_count = sum(1 for job in queue_jobs if job["status"] == "running")
    completed_count = sum(1 for job in queue_jobs if job["status"] == "completed")
    failed_count = sum(1 for job in queue_jobs if job["status"] == "failed")
    st.sidebar.metric("Queued", queued_count)
    st.sidebar.metric("Running", running_count)
    st.sidebar.metric("Completed", completed_count)
    st.sidebar.metric("Failed", failed_count)
    st.sidebar.caption(f"Last updated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    auto_refresh_enabled = st.sidebar.checkbox("Auto-refresh status", value=True, key="status_auto_refresh_enabled")
    refresh_seconds = st.sidebar.slider("Refresh interval (seconds)", min_value=5, max_value=60, value=10, step=1, key="status_auto_refresh_seconds")
    has_active_jobs = (queued_count + running_count) > 0
    active_symbols = {
        str(job.get("symbol"))
        for job in queue_jobs
        if str(job.get("status")) in {"queued", "running"}
    }
    selected_train_symbol = str(st.session_state.get("train_selected_symbol", "")).strip()
    overview_should_refresh = page == "Overview" and bool(selected_train_symbol) and selected_train_symbol in active_symbols

    if auto_refresh_enabled and has_active_jobs and (page in {"Training", "Queue"} or overview_should_refresh):
        st.sidebar.caption("Live auto-refresh active while jobs are running.")
        if overview_should_refresh:
            st.sidebar.caption(f"Overview live tracking: {selected_train_symbol}")
        components.html(
            f"""
            <script>
                setTimeout(function() {{
                    window.parent.location.reload();
                }}, {int(refresh_seconds) * 1000});
            </script>
            """,
            height=0,
            width=0,
        )

    if page == "Overview":
        render_overview(universe, status_merged, settings, _filter_universe, _decorate_status)

    elif page == "Training":
        render_training(
            status_merged,
            queue_jobs,
            unsupported_symbols,
            plan_summary,
            plan,
            _filter_universe,
            _decorate_status,
            queue_status_for_symbol,
            status_badge,
            last_failure_reason,
            enqueue_training_job,
            bulk_enqueue_with_checkpoint,
            enqueue_bulk_training_jobs,
            _resume_bulk_plan,
            _load_bulk_plan,
            _save_bulk_plan,
            cancel_jobs_by_symbols,
        )

    elif page == "Queue":
        render_queue(
            queue_jobs,
            queued_count,
            running_count,
            completed_count,
            failed_count,
            status_badge,
            get_job,
            reset_queue,
            bulk_plan_path,
        )

    elif page == "News":
        render_news(settings, status_merged, _filter_universe, _decorate_status)

    elif page == "News Impact Scanner":
        render_news_impact(settings)

    elif page == "Signal Backtesting":
        render_signal_backtesting(settings)

    elif page == "Predictions":
        render_predictions(settings)

    elif page == "Backtest":
        render_backtest(settings)

    elif page == "Watchlists & Alerts":
        render_watchlists_and_alerts()

    elif page == "Paper Trading & Journal":
        render_paper_trading()

    elif page == "Automation Monitor":
        render_automation_monitor()



if __name__ == "__main__":
    render_app(forced_page=None, show_page_picker=True)
