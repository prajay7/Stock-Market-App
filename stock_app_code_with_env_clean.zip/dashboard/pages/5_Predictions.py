from dashboard.streamlit_app import render_app

render_app(forced_page="Predictions", show_page_picker=False)
